<?php
    header("Location: shop/index.php"); 
?>