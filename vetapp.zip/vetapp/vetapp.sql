-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2024 at 04:45 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vetapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

CREATE TABLE `adminuser` (
  `ID` int(11) NOT NULL,
  `adminUsername` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `adminPassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`ID`, `adminUsername`, `firstName`, `lastName`, `adminPassword`) VALUES
(1, 'admin', 'Jane', 'Doe', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cart_ID` int(11) NOT NULL,
  `cart_userID` int(11) NOT NULL,
  `cart_itemID` int(11) NOT NULL,
  `cart_Quantity` int(11) NOT NULL,
  `cart_Total` int(11) NOT NULL,
  `cart_Date` datetime NOT NULL,
  `cart_Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `ID` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`ID`, `categoryName`) VALUES
(1, 'Services'),
(2, 'Products');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_items`
--

CREATE TABLE `tbl_items` (
  `item_ID` int(11) NOT NULL,
  `item_Image` varchar(255) NOT NULL,
  `item_Name` varchar(255) NOT NULL,
  `item_Description` varchar(255) NOT NULL,
  `item_Price` int(11) NOT NULL,
  `item_category` varchar(255) NOT NULL,
  `item_CategoryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_items`
--

INSERT INTO `tbl_items` (`item_ID`, `item_Image`, `item_Name`, `item_Description`, `item_Price`, `item_category`, `item_CategoryID`) VALUES
(1, '../assets/img/items/consultation.png', 'Consultation', 'Pet Consultation', 500, 'Services', 1),
(2, '../assets/img/items/grooming.png', 'Grooming', 'Pet Grooming', 1000, 'Services', 1),
(3, '../assets/img/items/deworming.png', 'Deworming', 'Pet Deworming', 800, 'Services', 1),
(4, '../assets/img/items/spray-neuter.png', 'Spray Neuter', 'Pet Spray and Neuter', 750, 'Services', 1),
(5, '../assets/img/items/vaccination.png', 'Vaccination', 'Pet Vaccination', 1200, 'Services', 1),
(6, '../assets/img/items/medicine.png', 'Medicine', 'Pet Medicine', 2000, 'Products', 2),
(7, '../assets/img/items/pet-grooming.png', 'Grooming Products', 'Pet Grooming Products', 650, 'Products', 2),
(8, '../assets/img/items/pet-leash.png', 'Leash', 'Pet Leash', 300, 'Products', 2),
(9, '../assets/img/items/pet-toys.png', 'Toys', 'Pet Toys', 150, 'Products', 2),
(10, '../assets/img/items/pet-bed.png', 'Bed', 'Pet Bed', 500, 'Products', 2),
(11, '../assets/img/items/pet-cage.png', 'Cage', 'Pet Cage', 900, 'Products', 2),
(12, '../assets/img/items/pet-crate.png', 'Crate', 'Pet Crate', 850, 'Products', 2),
(13, '../assets/img/items/pet-tag.png', 'Tag', 'Pet Tag', 150, 'Products', 2),
(14, '../assets/img/items/pet-bowls.png', 'Bowls', 'Pet Bowls', 180, 'Products', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notif`
--

CREATE TABLE `tbl_notif` (
  `notif_ID` int(11) NOT NULL,
  `notif_cartID` int(11) NOT NULL,
  `notif_dateTime` datetime NOT NULL,
  `notif_Status` int(11) DEFAULT 0,
  `notif_Purpose` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `order_subtotal` int(11) NOT NULL,
  `order_delivery` int(11) NOT NULL,
  `order_mode` varchar(255) NOT NULL,
  `order_total` int(11) NOT NULL,
  `order_Address` text NOT NULL,
  `order_refNo` varchar(55) NOT NULL,
  `order_startDate` datetime NOT NULL,
  `order_finishDate` datetime NOT NULL,
  `order_Status` varchar(255) NOT NULL,
  `order_finish` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_orderitems`
--

CREATE TABLE `tbl_orderitems` (
  `order_ID` int(11) NOT NULL,
  `order_itemsID` int(11) NOT NULL,
  `order_cartID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `post_ID` int(11) NOT NULL,
  `post_Image` varchar(255) NOT NULL,
  `post_Description` varchar(255) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `post_Status` varchar(255) NOT NULL,
  `post_Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usernotif`
--

CREATE TABLE `tbl_usernotif` (
  `notif_ID` int(11) NOT NULL,
  `order_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `notif_orderstatus` varchar(255) NOT NULL,
  `notif_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_ID` int(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactNumber` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `user_Address` varchar(255) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userConfirmPassword` varchar(255) NOT NULL,
  `user_orderHistory` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_ID`, `userName`, `firstName`, `lastName`, `email`, `contactNumber`, `gender`, `user_Address`, `userPassword`, `userConfirmPassword`, `user_orderHistory`) VALUES
(1, 'janedoe', 'Jane', 'Doe', 'janedoe@gmail.com', '09873232784', 'Male', 'Bacoor Cavite', '$2y$10$3Z1C/t2ysjyckMOiSTZBY.550C9mF7kcYogvtVjMkSjfpbf9JjS16', '$2y$10$3Z1C/t2ysjyckMOiSTZBY.550C9mF7kcYogvtVjMkSjfpbf9JjS16', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminuser`
--
ALTER TABLE `adminuser`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_ID`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_items`
--
ALTER TABLE `tbl_items`
  ADD PRIMARY KEY (`item_ID`);

--
-- Indexes for table `tbl_notif`
--
ALTER TABLE `tbl_notif`
  ADD PRIMARY KEY (`notif_ID`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_ID`);

--
-- Indexes for table `tbl_orderitems`
--
ALTER TABLE `tbl_orderitems`
  ADD PRIMARY KEY (`order_ID`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`post_ID`);

--
-- Indexes for table `tbl_usernotif`
--
ALTER TABLE `tbl_usernotif`
  ADD PRIMARY KEY (`notif_ID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminuser`
--
ALTER TABLE `adminuser`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_items`
--
ALTER TABLE `tbl_items`
  MODIFY `item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_notif`
--
ALTER TABLE `tbl_notif`
  MODIFY `notif_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_orderitems`
--
ALTER TABLE `tbl_orderitems`
  MODIFY `order_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `post_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_usernotif`
--
ALTER TABLE `tbl_usernotif`
  MODIFY `notif_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
