<footer style="position: relative; bottom: 0; width: 100%; background: #313131; color: white; text-align: center;padding:15px 30px;">
        <p style = "margin:0;">&copy; 2024 EMC Animal Clinic. All rights reserved.</p>
</footer>