<?php 
error_reporting(0); 
session_start();
include '../../shop/connection/database.php';
$sqlupdate = mysqli_query($conn, "UPDATE tbl_usernotif SET notif_status ='1'");

if(isset($_POST['cancelorder'])){
    $orderid = $_POST['orderID'];
    $userid = $_POST['idUser'];
    $sql = "UPDATE tbl_order SET cur_OrderStatus = '0' WHERE order_ID ='$orderid' AND user_ID = '$userid' ";
    $sqlres = mysqli_query($conn, $sql);
    if($sqlres){
        echo "<script>alert('success');
        window.location=document.referrer;
        </script>";
    }
    else{
        echo "<script>alert('failed');
        window.location=document.referrer;
        </script>";
    }
    $sql12 = "INSERT INTO  notif (notif_cartID, notif_DateTime, notif_Purpose) VALUE ('$orderid','$currentdate','CANCEL')";
    $sqlres = mysqli_query($conn, $sql12);
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>EMC Animal Clinic - Track Order</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <link rel="stylesheet" href="../assets/CSS/vieworder.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
</head>

<body style="background-color:whitesmoke;">
<?php require '../secondnav.php' ?>


<!--Modal-->
<?php
$sqlRemove = "SELECT * FROM `tbl_order` WHERE `user_ID`= '$userId' AND order_finish = '0' ORDER BY order_ID DESC";
    $removeresult = mysqli_query($conn, $sqlRemove);
    while($rowremove = mysqli_fetch_assoc($removeresult)){
        $orderid = $rowremove['order_ID'];
?>
<div class="modal fade" id="cancelOrder<?php echo $orderid?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cancel Order </h5>
            </div>
            <form method="POST" action="">
            <div class="modal-body">
                <h4> Are you sure you want to cancel your order?</h4>
            </div>
            <div class="modal-footer">
            <button type="submit" class="btn" value="" onclick = "" name="cancelorder" style = "background:black;color:white;">YES</button>
            <button id = "cancels" type="button" class="btn btn-danger" value="" onclick = "" data-dismiss="modal"  name="cancel">CANCEL</button>
            </div>

            <input type="hidden" value="<?php echo $orderid ?>" name="orderID">
            <input type="hidden" value="<?php echo $userId ?>" name="idUser">
            </form>
            </div>
        </div>
    </div>
</div>

<?php }?>
<?php 
$userSql = "SELECT * FROM `tbl_users` WHERE user_ID = '$userId'";
$sqluserres = mysqli_query($conn, $userSql);
$rowUsers = mysqli_fetch_assoc($sqluserres);
$OrderCount = $rowUsers['u_OrderCount'];

$sqlsel = "SELECT * FROM tbl_order WHERE user_ID = '$userId'";
$sqlu = mysqli_query($conn, $sqlsel);
$roow = mysqli_fetch_array($sqlu);
$cur_userID = $roow['user_ID'];
$order_status = $roow['order_Status'];


if($cur_userID == false){?>
         <div class="col-md-12 my-5">
            <div class="card" style="margin-top:230px;background:whitesmoke;border:none;overflow:hidden">
                <div class="card-body cart">
                    <div class="col-sm-12 empty-cart-cls text-center"> 
                        <img src="../assets/images/noorder.png" style = "width:250px;height:250px;" class="img-fluid mb-4">
                        <h3 style = "margin-top:-20px;"><strong>You dont have a Current Order yet</strong></h3>
                        <a href="../store/index.php" class="btn cart-btn-transform m-3" data-abc="true" style = "background:black;color:white;">Go to Store</a> 
                    </div>
                </div>
            </div>
        </div>
<?php
}
else{
?>
<div id = "order-title-container" class = "container">
    <div id = "order-title-card" class = "card">
        <h4 class = "orders-title">ORDERS</h4>
    </div>
</div>

<div id = "order-status" class="container">
    <div id="load"></div>
</div>

<script>
        $(document).ready(function () {

            $('#cancel-order').on('click', function () {

                $('#cancelOrder').modal('show');
            });
        });
    </script>


 
    <script>
    let set = setInterval(updateCountdown, 1000);
    function updateCountdown(){
        $("#load").load("load.php");
    }
        
    function showItems(id){
        clearInterval(set)
        document.getElementById("order-summary-main-header" + id).removeAttribute('hidden');
        document.getElementById("hideOrderSummary" + id).removeAttribute('hidden');
        document.getElementById("showOrderSummary" + id).setAttribute('hidden', 'hidden');
    }
    function hideItems(id){
      
        document.getElementById("order-summary-main-header" + id).setAttribute('hidden', 'hidden');
        document.getElementById("hideOrderSummary" + id).setAttribute('hidden', 'hidden');
        document.getElementById("showOrderSummary" + id).removeAttribute('hidden');
        /*let set = setInterval(updateCountdown, 1000);*/
    }
</script>

</div>
<?php }?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
