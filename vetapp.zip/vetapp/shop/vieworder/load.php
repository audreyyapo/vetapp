<?PHP 
include '../../shop/connection/database.php';
session_start();
$userId = $_SESSION['userId'];

$sqlemail = "SELECT * FROM tbl_users WHERE user_ID='$userId'";
$resulte = mysqli_query($conn, $sqlemail);
$rowe = mysqli_fetch_assoc($resulte);
$emailadd = $rowe['email'];


    $statusmodalsql = "SELECT * FROM `tbl_order` WHERE `user_ID`= '$userId' AND order_Status != 'CANCEL' AND order_finish = '0' ORDER BY order_ID DESC";
    $statusmodalresult = mysqli_query($conn, $statusmodalsql);
    while($statusmodalrow = mysqli_fetch_assoc($statusmodalresult)){
        
?>
    <article class="card" style = "background:whitesmoke;border:none;" >
        <div class="card-body" style="background:white;border:2px solid black;border-radius:5px 5px 5px 5px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);margin-bottom:20px;">
        <?php 
        $method = $statusmodalrow['order_mode'];
        $subtotal = $statusmodalrow['order_subtotal'];
        $totalpayment = $statusmodalrow['order_total'];
        $orderid = $statusmodalrow['order_ID'];
        $status = $statusmodalrow['order_Status'];
        $date1 = $statusmodalrow['order_startDate'];
        $refNo = $statusmodalrow['order_refNo'];
        $customaddress = $statusmodalrow['order_Address'];
        $deliveryfee = $statusmodalrow['order_delivery'];
        
        if ($status == "PENDING") 
            $tstatus = "Order Placed.";
        elseif ($status == "CONFIRM") 
            $tstatus = "Order Confirmed.";
        elseif ($status == "FINISH")
            $tstatus = "Order Delivered.";
        else 
            $tstatus = "Order Cancelled.";
   
?>                          <div class = "for-header">
                                <div class = "for-orderid">
                                <h6><strong>Order Referrence #:</strong><?php echo $refNo ?></h6>
                                </div>
                                <div class = "for-date">
                                <h6><strong></strong><?php echo $status;?><?php if($status== "CONFIRM"){ ?>ED<?php } ?></h6>
                                </div>
                            </div>
                            
                            <div class="track" id="delivery">
                            <div id="load"></div>
                                                    <script>
                            
                            $(document).ready(function()
                            {
                                setInterval(function(){
                                    $("#s").load("load.php");
                                },300);
                                });
                            
                                </script>

                
                            <?php
                              if($status == "PENDING"){
                                      echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                            <div class="step"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text">Order Confirmed</span> </div>
                                            <div class="step"> <span class="icon"> <i class="fa fa-box"></i> </span> <span class="text">Order Delivered</span> </div>
                                            ';
                                }
                                else if($status == "CONFIRM"){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Confirmed</span> </div>
                                          <div class="step"> <span class="icon"> <i class="fa fa-box"></i> </span> <span class="text">Order Delivered</span> </div>';
                                }
                                else if($status == "FINISH"){
                                    echo '<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Placed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Confirmed</span> </div>
                                          <div class="step active"> <span class="icon"> <i class="fa fa-box"></i> </span> <span class="text">Order Delivered</span> </div>';
                                }
                               
                                else {
                                    echo '<div class="step deactive"> <span class="icon"> <i class="fa fa-times"></i> </span> <span class="text">Order Cancelled.</span> </div>';
                                }
                             
                            ?>
                           
                            </div>
                            <?php  
                            
                                if($status == "PENDING"){
                                    echo ' <form action="functions.php" method="POST">
                                    <input type="hidden" name="idUser" value="' . $userId . '">
                                    <input type="hidden" name="orderID" value="' . $orderid . '">
                                    <button id ="cancel-order" type="submit" name = "cancelorder" class="btn btn-danger">Cancel Order</button>
                                    </form>
                                   ';
                                }
                            
                                if($status  == "FINISH"){
                                    echo ' <form action="functions.php" method="POST">
                                    <input type="hidden" name="idUser" value="' . $userId . '">
                                    <input type="hidden" name="orderID" value="' . $orderid . '">
                                    <input type="hidden" name="emails" value="' . $emailadd . '">

                                  <button id="receive-order" type="submit" name="received" class="btn btn-primary" style="">Order Received</button>
                                  </form>
                                   ';
                                } ?>
                                 <hr class = "order-summary-hr">
                                 <div class = "show-button" style ="width:100%;text-align:right;">
                                    <button type = "button" id = "showOrderSummary<?php echo $orderid; ?>" class = "showOrderSummary" onclick = "showItems(<?php echo $orderid; ?>);" style = "border:none;outline:none;background:transparent;">Order Summary <i class = "fas fa-caret-down"></i></button>
                                    <button type = "button" id = "hideOrderSummary<?php echo $orderid; ?>" class = "hideOrderSummary" onclick = "hideItems(<?php echo $orderid; ?>);"style = "border:none;outline:none;background:transparent;" hidden>Hide <i class = "fas fa-caret-up"></i></button>
                                </div>
                                
                                <div id ="order-summary-main-header<?php echo $orderid ?>" class = "order-summary-main-header"hidden >
                                 <h4 class = "order-summary-header">Order Details</h4>
                                <?php
                                    $mysql = "SELECT * FROM `tbl_orderitems` WHERE order_itemsID = '$orderid' ";
                                    $myresult = mysqli_query($conn, $mysql);
                                    while($myrow = mysqli_fetch_assoc($myresult)){
                                       
                                        $idOrder = $myrow['order_ID'];
                                        $currentOrdersID = $myrow['order_itemsID'];
                                        $cartID = $myrow['order_cartID'];
                                   
                                  
                                        $sqlcart = "SELECT * FROM tbl_cart WHERE cart_ID = '$cartID' and cart_userID ='$userId'";
                                        $sqlress  = mysqli_query($conn, $sqlcart);
                                        $rowcart =  mysqli_fetch_array($sqlress);
                                        $cartUserID = $rowcart['cart_userID']; 
                                        $quantity =  $rowcart['cart_Quantity'];   
                                        $date = $rowcart['cart_Date'];
                                        $cart_itemID = $rowcart['cart_itemID'];
                                        

                                        $sqlmenu = "SELECT * FROM tbl_items WHERE item_ID = '$cart_itemID'";
                                        $sqlrr  = mysqli_query($conn, $sqlmenu);
                                        $menurow =  mysqli_fetch_array($sqlrr);
                                        $menuName = $menurow['item_Name'];
                                        $price = $menurow['item_Price'];
                                        
                                        $total = $price * $quantity;
                                      
                                    ?>
           


            <div class = "order-item">
            <p class= "order-item-pLeft" style=""> <?php echo $quantity ?> x</p>
            <p class= "order-item-pCenter" style=""><?php echo $menuName ?></p>
            <p class= "order-item-pRight" style="">₱ <?php echo $price?>.00 </p>           
            </div>
        <?php }?>
            
            <hr class = "order-summary-hr">
            <div class = "order-summary-total-fee">
        
                <div class="order-summary-sub-total">
                    <p class="order-summary-subtotal-pLeft">Subtotal</p>
                    <p class="order-summary-subtotal-pRight">₱ <?php echo $subtotal?>.00</p>
                </div>
                     
                <div class ="order-summary-delivery-fee">
                    <p class="order-summary-delivery-pLeft">Delivery Fee</p>
                        
                    <p class="order-summary-delivery-pRight">₱ <?php echo $deliveryfee?>.00</p>

                </div>

                <div class = "order-summary-total">
                    <p class="order-summary-total-pLeft">Total</p>
                    <p class="order-summary-total-pRight">₱<?php echo $totalpayment?>.00</p>
                </div>
            </div>
            <hr>
            
            </div> 
            
            <div style = "width:100%;display:flex;">
            <p style = "width:100%;font-weight:bold;">Delivery Address: </p>
            <p style = "float:right;width:100%;text-align:right;"><?php echo $customaddress;?></p>
             </div>
            <div style = "width:100%;display:flex;">
            <p style = "width:100%;font-weight:bold;">Date Ordered: </p>
            <p style = "float:right;width:100%;text-align:right;"><?php echo $date1;?></p>
             </div>
            </div>

    
        </article>
        <?php } ?>

        

        