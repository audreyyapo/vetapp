<?php 
error_reporting(0); 
session_start();
include '../../shop/connection/database.php';

if(isset($_POST['cancelorder'])){
    $orderid = $_POST['orderID'];
    $userid = $_POST['idUser'];
    $sql = "UPDATE tbl_order SET order_Status = 'CANCEL' WHERE order_ID ='$orderid' AND user_ID = '$userid' ";
    $sqlres = mysqli_query($conn, $sql);
    if($sqlres){
        echo "<script>alert('Order has been cancel!');
        window.location=document.referrer;
        </script>";
    }
    else{
        echo "<script>alert('failed');
        window.location=document.referrer;
        </script>";
    }
    $sql12 = "INSERT INTO tbl_notif (notif_cartID, notif_dateTime, notif_Purpose) VALUE ('$orderid','$currentdate','CANCEL')";
    $sqlres = mysqli_query($conn, $sql12);
}
?>