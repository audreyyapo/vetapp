<nav class="navbar navbar-expand-lg" style="position: fixed;top:0;width:100%;z-index:999;">
  <div class="container-fluid">
    <a class="navbar-brand" href="../../shop/index.php">
        <img src = "../../shop/assets/images/vetapp-logo.jpeg" style = "height:65px;width:75px;"/>
    </a>
    <ul class="navbar-nav ms-auto" style = "display:flex;flex-direction:row;gap:25px;">
        <li class="nav-item">
          <a class="nav-link text-center" aria-current="page" href="../../shop/index.php"><i class="fa-solid fa-house"></i><br>Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-center" href="../../shop/signin/"><i class="fa-solid fa-right-to-bracket"></i><br>Login</a>
        </li>
      </ul>
  </div>
</nav>