<?php
include '../../shop/connection/database.php';
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    $loggedin = true;
    $userId = $_SESSION['userId'];
    $email = $_SESSION['email'];
  }
  
  else if (!isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == false) {
    header("location:../index.php");
  }
  
  else{
      header("location:./_index.php");
  }


$sql = "SELECT * FROM tbl_users WHERE user_ID='$userId'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$firstName = $row['firstName'];
?>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>

<nav class="navbar navbar-expand-lg " style="position: fixed;top:0;width:100%;z-index:999;">
  <div class="container-fluid">
  <a class="navbar-brand" href="../index.php">
        <img src = "../../shop/assets/images/vetapp-logo.jpeg"/>
    </a>
  
      <ul class="navbar-nav ms-auto" style = "display:flex;flex-direction:row;gap:25px;">
        <li class="nav-item">
          <a class="nav-link text-center text-white" aria-current="page" href="../../shop/store"><i class="fa-solid fa-store"></i><br>Store</a>
        </li>

        <?php 
          $sql = "SELECT SUM(cart_Quantity) AS total_quantity FROM tbl_cart WHERE cart_userID = '$userId' AND cart_Status = 'PENDING'";
          $result = mysqli_query($conn, $sql);
          $row = mysqli_fetch_assoc($result);
          $totalQuantity = $row['total_quantity'];
        ?>
        <li class="nav-item">
          <a class="nav-link text-center text-white" href="../../shop/cart"><i class="fa-solid fa-cart-shopping"></i><br>Cart
          <?php if($totalQuantity == 0){
            $hidden = "hidden";
          }?>
            <p id = "cart-count" <?php echo $hidden?>><?php echo $totalQuantity ?></p>
         
         
        </a>
        </li>
        <li class="nav-item dropstart">
          <a class="nav-link text-center text-white dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fa-solid fa-bell"></i><br>Notification
          <div id="loadnotifnum"></div>
          </a>
          <ul class="dropdown-menu" style="position: absolute;z-index:999;padding:0;">
          <div id="loadnotif"></div>
          <a href="../vieworder" class="dropdown-item text-center">View all orders</a>
         
          </ul>
        </li>
        <li class="nav-item dropstart">
          <a class="nav-link text-center text-white dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fa-solid fa-user"></i><br><?php echo $firstName;?>
          </a>
          <ul class="dropdown-menu" style="position: absolute;z-index:999;">
            <li><a class="dropdown-item" href="../../shop/profile"><i class="fa-solid fa-user"></i> Profile</a></li>
            <li><a class="dropdown-item" href="../../shop/vieworder"><i class="fa-solid fa-magnifying-glass"></i> Track Order</a></li>
            <li><a class="dropdown-item" href="../../shop/history"><i class="fas fa-receipt"></i> Order History</a></li>
            <li><a class="dropdown-item" href="../../shop/connection/logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <script>
  $(document).ready(function()
     {
        setInterval(function(){
            $("#loadnotif").load("../loadnotif.php");
        },300);
        });
   $(document).ready(function()
     {
        setInterval(function(){
            $("#loadnotifnum").load("../notifnum.php");
        },300);
        });
</script>
</nav>

</html>



