<?php
session_start();
include '../connection/database.php';

$myId = $_SESSION['userId'];

  $sqlprof = "SELECT * FROM tbl_users WHERE user_ID = '$myId'";
  $sqlres = mysqli_query($conn,$sqlprof);
  $row = mysqli_fetch_assoc($sqlres);

  $email = $row['email'];
  $fname = $row['firstName'];
  $lname = $row['lastName'];
  $gender =$row['gender'];
  $address =$row['user_Address'];
  $contact = $row['contactNumber'];
  $user =  $row['userName'];
  $pass = $row['userPassword'];

    if(isset($_POST['change'])){
        $lname = mysqli_real_escape_string($conn, $_POST['lname']);
        $fname = mysqli_real_escape_string($conn, $_POST['fname']);
        $genders = mysqli_real_escape_string($conn, $_POST['gender']);
        $address2 = mysqli_real_escape_string($conn, $_POST['address']);
        $contact = $_POST['phone'];
        $pass = $_POST['password'];
        $pass2= $_POST['confirmpass'];
      if($pass2 == $pass){
        $encpass = password_hash($pass2, PASSWORD_BCRYPT);
        $sqlup = mysqli_query($conn, "UPDATE tbl_users SET firstName = '$fname', lastName = '$lname', contactNumber='$contact', gender = '$genders', user_Address = '$address2', userPassword='$encpass', userConfirmPassword = '$encpass' WHERE user_ID = '$myId'");
        echo'<script> alert("Information Successfully changed.");
        window.location=document.referrer;</script>";';
      }
      else{
        echo'<script> 
        alert("Failed to change information");
        window.location=document.referrer;</script>";';
      }
    }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EMC Animal Clinic - Profile</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="../assets/css/navbar.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>


</head>

<body>
<?php
session_start();
if(isset($_SESSION['loggedin'])){
    require '../secondnav.php';
}
else{
    require '../firstnav.php';
}
?>

    <div class="container-fluid pt-4 px-4 pb-4" style = "margin-top:100px;">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-light rounded h-100 p-4" >
                <h6 class="mb-4"></h6>
                <div class="container-xl px-4 mt-4 mb-4">
                    <div class="row">
                        <div class="col-xl-4">
                            <!-- Profile picture card-->
                            <div class="card mb-4 mb-xl-0">
                                <div class="card-header">Profile Picture</div>
                                <div class="card-body text-center">
                                   
                                    <img class="img-account-profile rounded-circle mb-2" src="../../shop/assets/images/profile.png" style="width: 100%; height: 50%;"alt="">
                            
                                    <div class="small font-italic text-muted mb-4"><?php echo $fname .' '. $lname?></div>
                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8">
                            <!-- Account details card-->
                            <div class="card mb-4">
                                <div class="card-header">Account Details</div>
                                <div class="card-body">
                                    <form method="POST">
                                        <div class="row gx-3 mb-5">
                                            <div class="col-md-6">
                                            <label class="small mb-1" for="inputUsername">Email</label>
                                            <input class="form-control" id="inputUsername" name="email" type="text" placeholder="Email Address" value="<?php echo $email?>" readonly style = "opacity:0.5">
                                            </div>
                                         
                                            <div class="col-md-6">
                                            <label class="small mb-1" for="inputUsername">Username</label>
                                            <input class="form-control" id="inputUsername" name="username" type="text" placeholder="Username" value="<?php echo $user?>" readonly style = "opacity:0.5">
                                            </div>
                                      
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputFirstName">First name</label>
                                                <input class="form-control" id="inputFirstName" name="fname" type="text" placeholder="Enter your first name" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" value="<?php echo $fname?>">
                                            </div>
                                         
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Last name</label>
                                                <input class="form-control" id="inputLastName" name="lname" type="text" placeholder="Enter your last name" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" value="<?php echo $lname?>">
                                            </div>

                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputFirstName">Gender</label>
                                                <input class="form-control" id="inputFirstName" name="gender" type="text" placeholder="Gender" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" value="<?php echo $gender?>">
                                            </div>
                                         
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Contact Number</label>
                                                <input class="form-control" id="inputLastName" placeholder="09123456789 " name="phone" required pattern="[0-9]{11}" maxlength="11" onkeypress="if(event.keyCode<48 || event.keyCode>57)event.returnValue=false;" value="<?php echo $contact?>">
                                            </div>

                                            <div class="col-md-12">
                                                <label class="small mb-1" for="inputLastName">Address</label>
                                                <input class="form-control" id="inputLastName" name="address" type="text" placeholder="Address" value="<?php echo $address?>">
                                            </div>
                                      
                                            
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Password</label>
                                                <input class="form-control" id="inputLastName" name="password" type="password" placeholder="Enter your last name" minlength="8" maxlength="" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;" value="<?php echo $pass?>">
                                            </div>

                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Confirm Password</label>
                                                <input class="form-control" id="inputLastName"  name="confirmpass" type="password" placeholder="Confirm Password" minlength="8" maxlength="" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;" value="<?php echo $pass?>">
                                            </div>
                                            
                                            
                                        </div>
                                        <br><br>
                                        <button class="btn btn-primary" type="submit" name="change" >Save changes</button>
                                        </div>
                                
                                      
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Table End -->


        <!-- Content End -->


        <!-- Back to Top -->
      
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>
