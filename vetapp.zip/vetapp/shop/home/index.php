<?php 
include '../../shop/connection/database.php';


if(isset($_POST['addPost'])){

    $userID = $_POST['user_ID'];
    $status = "ACTIVE";
    $post_description = $conn -> real_escape_string($_POST['post_description']);
  
    $name = $_FILES['file']['name'];
    $fileExt = explode('.', $name);
    $fileActualExt = strtolower(end($fileExt));
    $target_dir = "../../shop/assets/images/post/";
    $target_file = $target_dir . $name;
    $extensions_arr = array("jpg","png","jpeg");
    if(in_array($fileActualExt,$extensions_arr) ){
       
            if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                $sqladd = "INSERT INTO `tbl_post` (`post_Image`,`post_Description`, `user_ID`,`post_Status`,`post_Date`) VALUES ('$target_file','$post_description','$userID','$status','$currentdate')";
                $results = mysqli_query($conn, $sqladd);
                if($results){
                   echo'
                   <script>alert("Post has been successfully added.");
                     window.location = \'../index.php\';
                    </script>
                   ';
                }
            }
            else{
                echo'
                <script>alert("Failed to add Post.");
                    window.location = \'../index.php\';
                     </script>
                ';
            }
        }
    
  }



  if(isset($_POST['editPosts'])){
    $desc = $conn->real_escape_string($_POST['desc']);
    $id = $_POST['postid'];
    // Check if a new image file is uploaded
    if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) {
        $name = $_FILES['file']['name'];
        $fileExt = explode('.', $name);
        $fileActualExt = strtolower(end($fileExt));
        $target_dir = "../../shop/assets/images/post/";
        $target_file = $target_dir . $name;
        $extensions_arr = array("jpg","png","jpeg");

        if(in_array($fileActualExt,$extensions_arr)) {
            if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                // If image uploaded successfully, update database with new image
                $sqladd = "UPDATE tbl_post SET post_Image = '$target_file', post_Description='$desc' WHERE post_ID = '$id'";
                $results = mysqli_query($conn, $sqladd);
                if($results){
                    echo '<script>alert("Post Updated Successfully!"); window.location = \'../index.php\';</script>';
                } else {
                    echo '<script>alert("Failed to update post!"); window.location = \'../index.php\';</script>';
                }
            } else {
                echo 'failed';
            }
        }
    } else {
    // If no new image uploaded, update database with existing image
        $sqladd = "UPDATE tbl_post SET post_Description='$desc' WHERE post_ID = '$id'";
        $results = mysqli_query($conn, $sqladd);
        if($results){
            echo '<script>alert("Post Updated Successfully!"); window.location = \'../index.php\';</script>';
        } else {
            echo '<script>alert("Failed to update post!"); window.location = \'../index.php\';</script>';
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMC Animal Clinic - Home</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">

</head>
<body>
    
<?php
session_start();
if(isset($_SESSION['loggedin'])){
    require '../secondnav.php';
}
else{
    require '../firstnav.php';
}
?>

<div id = "main-container-vetapp" class="container-sm pt-5">

<?php if(isset($_SESSION['loggedin'])){?>
    <h2>Share something!</h2>
  <div class = "post-items mt-3">
    <form action="" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
    <textarea class="form-control" id="sharedpost" name="post_description" placeholder = "Share your post" maxlength="200" minlength="20"></textarea>
    <div class="post-items d-flex flex-row gap-2 mb-3 mt-3">
        <input type="file" id = "picture-upload" name="file" accept="image/*" class="form-control" required>
        <button id = "add-post" type="submit" name = "addPost" class="btn btn-primary">Post</button>
    </div>
    <input type="hidden" name="user_ID" value="<?php echo $_SESSION['userId'];?>">
   
    </form>
  </div>
</div>

<div id = "main-container-home" class="container-sm">
<h1>NEWS FEED</h1>
<div class = "news-feed-container">

<?php
// Function to get the appropriate string for time ago
function getTimeAgoString($minutes_ago) {
    if ($minutes_ago < 2) {
        return "1 minute ago";
    } elseif ($minutes_ago < 60) {
        return $minutes_ago . " minutes ago";
    } elseif ($minutes_ago < 120) {
        return "1 hour ago";
    } elseif ($minutes_ago < 1440) {
        return round($minutes_ago / 60) . " hours ago";
    } elseif ($minutes_ago < 2880) {
        return "1 day ago";
    } elseif ($minutes_ago < 43200) {
        return round($minutes_ago / 1440) . " days ago";
    } elseif ($minutes_ago < 86400) {
        return "1 month ago";
    } elseif ($minutes_ago < 525600) {
        return round($minutes_ago / 43200) . " months ago";
    } elseif ($minutes_ago < 1051200) {
        return "1 year ago";
    } else {
        return round($minutes_ago / 525600) . " years ago";
    }
}

$sql = "SELECT * FROM tbl_post WHERE post_Status = 'ACTIVE' ORDER BY post_Date ASC";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)){
    $post_ID = $row ['post_ID'];
    $userID = $row['user_ID'];
    // Convert post date to DateTime object
    $post_date = new DateTime($row['post_Date']);
    // Get current date and time
    $current_date = new DateTime();
    // Calculate the difference between current time and post time
    $time_diff = $current_date->diff($post_date);
    // Format the time difference into minutes ago
    $minutes_ago = $time_diff->days * 24 * 60 + $time_diff->h * 60 + $time_diff->i;

    // Fetch user information
    $sqlUser = "SELECT * FROM tbl_users WHERE user_ID = '$userID'";
    $resultUser = mysqli_query($conn, $sqlUser);
    $rowUser = mysqli_fetch_assoc($resultUser);
    $user_name = $rowUser['firstName'] . " " . $rowUser['lastName'];
?>

<div class="card">
    <img src="<?php echo $row['post_Image'];?>" class="card-img-top" alt="Post Item">
    <div class="card-body">
        <p class="card-text"><?php echo $row['post_Description'];?></p>
        <p class="card-text"><small class="text-muted">Posted by: <?php echo $user_name;?></small></p>
        <!-- Display post date in minutes ago format -->
        <p class="card-text"><small class="text-muted"><?php echo getTimeAgoString($minutes_ago);?></small></p>
        <?php if ($userId == $userID ){?>
            <button id = "post-edit" type="button" class="btn" data-bs-toggle="modal" data-bs-target="#editPost<?php echo $post_ID ?>">Edit</button>
        <?php }?>
    </div>
</div>

<?php } ?>



</div>
</div>


<?php }
else{?>
<div id = "home-container" class="container-sm">
<h2>Share something!</h2>
<div class = "mt-3">
<form action="" method="POST" enctype="multipart/form-data">
    <textarea class="form-control" id="sharedpost" placeholder = "Share your post" rows="5" disabled></textarea>
    <div class="post-items d-flex flex-row gap-2 mb-3 mt-3">
        <input type="file" id = "picture-upload" name="file" accept="image/*" class="form-control" required disabled>
        <button id = "add-post" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal">Post</button>
    </div>
   
    </form>
  </div>
</div>
<?php }?>

<?php 
$sqlCount = "SELECT COUNT(*) AS active_count FROM tbl_post WHERE post_Status = 'ACTIVE'";
$resultcount = mysqli_query($conn, $sqlCount);
$rowcount = mysqli_fetch_assoc($resultcount);
$activeCount = $rowcount['active_count'];
?>


<?php if($activeCount < 1){?>
    <div class = "mb-5 text-center"><h2>There is no available post by users.</div>
<?php }?>

<div id = "home-container" class="home-container container-sm" >
<div class="row">
    <div class="clinic-info col-md-6">
      <h2>EMC Animal Clinic since 2017</h2>
      <p><strong>Opening Hours:</strong> 8:00am to 6:00pm everyday except Sunday</p>
      <p><strong>Address:</strong> Unit 8, Alnica Building, Patindig Araw Rd, Imus, Cavite</p>
      <p><strong>Contact Number:</strong> 09082929739 / (046) 6865540</p>
    </div>
    <div class="col-md-6 d-flex flex-column justify-content-center">
    <div class = "map-container">
        <div id="my-map-display" style="height:100%; width:100%;max-width:100%;">
            <iframe frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=+Unit+8,+Alnica+Building,+Patindig+Araw+Rd,+Imus,+Cavite&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe>
        </div>
        <style>#my-map-display img{max-height:none;max-width:none!important;background:none!important;}</style></div>
    </div>
  </div>
</div>

<?php require '../footer.php'; ?>

<!-- Modal -->
<div class="modal fade" id="loginModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loginModal" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header d-flex justify-content-between" style = "background:#313131;">
        <h1 class="modal-title fs-5 text-white" id="loginModalLabel">Please Login!</h1>
        <button type="button" class="btn text-white" data-bs-dismiss="modal"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="modal-body">
        <h3>Sorry you need to login first to post something! Thank you.</h3>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn" onclick="window.location.href = '../signin';" style = "background:#313131;color:#fff;">LOGIN</button>
      </div>
    </div>
  </div>
</div>


<!-- Edit Product Modals -->
<?php
$sqlitems = "SELECT * FROM tbl_post";
$sqlres = mysqli_query($conn, $sqlitems);  
while($row = mysqli_fetch_assoc($sqlres)){
    $ids = $row['post_ID'];
    $image = $row['post_Image'];  
    $description = $row['post_Description'];
?>

<div class="modal fade" id="editPost<?php echo $ids?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Post</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                    <input type="hidden" name="postid" value="<?php echo $ids ?>">
                    <div class="form-group">
                        <img src = "<?php echo $image ?>" style = "height:70px;width:70px;"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Input Image</label>
                        <input type="file" name="file" accept="image/*" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>
                        <textarea class="form-control"  rows="5" maxlength="200" minlength="20" name="desc" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;"><?php echo $description?></textarea>
                    </div>
                
                </div>
                <div class="modal-footer">
                    <button type="submit" name="editPosts" class="btn btn-primary">SAVE</button>
                    </form>
                </div>

            
        </div>
    </div>
</div>

<?php } ?>
<script>
    function validateForm() {
        var desc = document.getElementsByName("desc")[0].value;
        var maxLength = 200;
        var minLength = 20;

        // Check if the length of the description is within the allowed range
        if (desc.length > maxLength) {
            alert("Description should not exceed 200 characters.");
            return false;
        } else if (desc.length < minLength) {
            alert("Description should be at least 20 characters.");
            return false;
        }
        return true;
    }
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>