<?php 
error_reporting(0); 
session_start();
include '../../shop/connection/database.php';
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>EMC Animal Clinic - Order History</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
   
    <link rel="stylesheet" href="../assets/css/orderHistory.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
   
</head>
<body style="background:whitesmoke;" >
<?php require '../secondnav.php' ?>


<?php
$userSql = "SELECT * FROM `tbl_users` WHERE user_ID = '$userId'";
$sqluserres = mysqli_query($conn, $userSql);
$rowUsers = mysqli_fetch_assoc($sqluserres);
$OrderHistory = $rowUsers['user_orderHistory'];
?>

<?php if($OrderHistory== 0){?>
    <div>
        <div class="col-md-12 my-5"><div class="card" style="margin-top:230px;background:whitesmoke;border:none;">
            <div class="card-body cart"><div class="col-sm-12 empty-cart-cls text-center"> 
                <img src="../assets/images/noorder.png" style = "width:250px;height:250px;" class="img-fluid mb-4 ">
                <h3><strong>You dont have a Finish Order yet</strong></h3>
                <a href="../store/index.php" class="btn cart-btn-transform m-3" data-abc="true" style = "background:black;color:white;">Go to Store</a>
            </div>
        </div>
    </div>
<?php }
else{
?>
<div id = "order-details-container" class = "container">
<h2 class = "order-details-date" style="font-weight:bold;">ORDER HISTORY</h2>
<?php
    $sql = "SELECT * FROM tbl_order WHERE user_ID = '$userId' AND order_finish = '1' ORDER BY order_ID DESC";
    $sqlress1 = mysqli_query($conn,$sql);
    while($rowf = mysqli_fetch_assoc($sqlress1)){
        $method = $rowf['order_mode'];
        $subtotal = $rowf['order_subtotal'];
        $totalpayment = $rowf['order_total'];
        $orderid = $rowf['order_ID'];
        $status = $rowf['order_Status'];
        $date = $rowf['order_startDate'];
        $customaddress = $rowf['order_Address'];
        $finishdate = $rowf['order_finishDate']; 
        $deliveryf =   $rowf['order_delivery']; 
        $refNo = $rowf['order_refNo'];
        $tax = $subtotal * .12;
        $tax =  number_format((float)$tax, 2, '.', '');       
        $subtotal =  number_format((float)$subtotal, 2, '.', '');     
        $totalpayment =  number_format((float)$totalpayment, 2, '.', '');     
?>
<div id = "order-details-card" class = "card" style = "background:whitesmoke;border:none;">
    <div id ="order-details" class = "card-body"  style = "background:white;">
    <?php $mysql = "SELECT * FROM `tbl_orderitems` WHERE order_itemsID = '$orderid' ";
        $myresult = mysqli_query($conn, $mysql);
         ?>
        <div class = "order-details-main">
            <div class = "for-order-id">
                <form method = "POST" action="functions.php">
            <h4 class = "order-details-header">Order Referrence #: <?php echo $refNo ?></h4>
            </div>
            <div class = "for-reorder-button">

            <button type = "submit" name="reorder"id = "reorder" class = "btn">REORDER</button>
            <input type="hidden" value="<?php echo $orderid ?>" name="orderid">
        </form>
            </div>
        </div>
     
            <hr class = "order-header-hr">
            <div class = "order-details-view-details">
                <div class = "view-details-button" style="width:100%;text-align:right;">
                <button type = "button" id = "showOrderSummary<?php echo $orderid; ?>" class = "btn showOrderSummary" onclick = "showItems(<?php echo $orderid; ?>);" style = "border:none;outline:none;background:transparent;">
                    
                View Order Details <i class = "fas fa-caret-down"></i>
                </button>
                <button type = "button" id = "hideOrderSummary<?php echo $orderid; ?>" class = "btn hideOrderSummary" onclick = "hideItems(<?php echo $orderid; ?>);"style = "border:none;outline:none;background:transparent;" hidden>
                    Hide <i class = "fas fa-caret-up"></i>
                </button>
                </div>           
            </div>
            
            <div class = "view-details-items-main" id = "view-details-items-main<?php echo $orderid ?>" hidden>
            <hr>
            <?php
            while($myrow = mysqli_fetch_assoc($myresult)){
           
                $idOrder = $myrow['order_ID'];
                $currentOrdersID = $myrow['order_itemsID'];
                $cartID = $myrow['order_cartID'];

                $sqlcart = "SELECT * FROM tbl_cart WHERE cart_ID = '$cartID' and cart_userID ='$userId'";
                $sqlress  = mysqli_query($conn, $sqlcart);
                $rowcart =  mysqli_fetch_array($sqlress);

                $cartUserID = $rowcart['cart_userID']; 
                $quantity =  $rowcart['cart_Quantity'];  
                $date = $rowcart['cart_Date'];
                $cart_itemID = $rowcart['cart_itemID'];
                    
        
                $sqlmenu = "SELECT * FROM tbl_items WHERE item_ID = '$cart_itemID'";
                $sqlrr  = mysqli_query($conn, $sqlmenu);
                $menurow =  mysqli_fetch_array($sqlrr);
                $menuName = $menurow['item_Name'];
                $Image = $menurow['item_Image'];
                $price = $menurow['item_Price'];

               ?>
            <div class = "orders-header">
                <div class = "order-image">
                    <img src = "../../admin/assets/<?php echo $Image ?>">
                </div>
                <div class = "order-details">
                    <p class = "item-name"><?php echo $menuName ?></p> 
                    <p class = "item-quantity">x<?php echo $quantity ?></p>
                </div>
                <div class = "order-details-price">
                    <p>₱ <?php echo $price?>.00</p>
                </div>
                <hr>
            </div>
            <?php }?>
       
            <div id = "view-details-total-breakdown" class = "view-details-total-breakdown">
            <hr>
                <div class = "view-details-subtotal">
                    <p class = "view-details-subtotal-pLeft">Subtotal</p>
                    <p class ="view-details-subtotal-pRight">₱ <?php echo $subtotal?></p>
                </div>
                <div class = "view-details-delivery-fee">
                    <p class = "view-details-delivery-fee-pLeft">Delivery Fee</p>
                    <p class = "view-details-delivery-fee-pRight">₱ <?php echo   $deliveryf?>.00</p>
                </div>
                <div class = "view-details-total">
                    <p class = "view-details-total-pLeft">Total</p>
                    <p class = "view-details-total-pRight">₱ <?php echo $totalpayment?></p>
                </div>
                <hr>
                <div>
                    <div class = "for-payment-method" style = "display:flex;width:100%;">
                    <h6 style = "text-align:left;width:50%;">Order Method: </h6>
                    <h6 style = "text-align:right;width:50%;"><?php echo $method ?></h6>
                    </div>
                    <div class = "for-date-ordered" style = "display:flex;width:100%;">
                    <h6 style = "text-align:left;width:40%;">Delivery Address: </h6>
                    <h6 style = "text-align:right;width:60%;"><?php echo $customaddress ?></h6>
                    </div>
                    <div class = "for-date-ordered" style = "display:flex;width:100%;">
                    <h6 style = "text-align:left;width:50%;">Date Ordered: </h6>
                    <h6 style = "text-align:right;width:50%;"><?php echo $date ?></h6>
                    </div>

                    <div class = "for-date-ordered" style = "display:flex;width:100%;">
                    <h6 style = "text-align:left;width:50%;">Finish Transactions: </h6>
                    <h6 style = "text-align:right;width:50%;"><?php echo $finishdate ?></h6>
                    </div>
                </div>
            </div>
    </div>
</div>

<?php } ?>

</div>
<?php } ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>

function showItems(id){
document.getElementById("view-details-items-main" + id).removeAttribute('hidden');
document.getElementById("hideOrderSummary" + id).removeAttribute('hidden');
document.getElementById("showOrderSummary" + id).setAttribute('hidden', 'hidden');
}
function hideItems(id){
document.getElementById("view-details-items-main" + id).setAttribute('hidden', 'hidden');
document.getElementById("hideOrderSummary" + id).setAttribute('hidden', 'hidden');
document.getElementById("showOrderSummary" + id).removeAttribute('hidden');
}
</script>
</body>
</html>
