<?php 
include '../../shop/connection/database.php';
session_start();
$userId = $_SESSION['userId'];

if(isset($_POST['reorder'])){
    $orderid = $_POST['orderid'];

    $sql = mysqli_query($conn, "SELECT * FROM tbl_orderitems WHERE order_itemsID = '$orderid'");
    while($row = mysqli_fetch_array($sql)){
        $cartID = $row['order_cartID'];
        $sqlcart = "SELECT * FROM tbl_cart WHERE cart_ID = '$cartID' and cart_userID ='$userId'";
        $sqlress  = mysqli_query($conn, $sqlcart);
        $rowcart =  mysqli_fetch_array($sqlress);
        $quantity =  $rowcart['cart_Quantity'];
        $cart_itemID = $rowcart['cart_itemID'];
        $cart_total = $rowcart['cart_Total'];
        $status = "PENDING";
        if($quantity == '0'){
            $quantity = "1";
        } 
        $sql1 = "INSERT INTO `tbl_cart` (`cart_userID`,`cart_itemID`, `cart_Quantity`, `cart_Total`,`cart_Date`,`cart_Status`) 
        VALUES ('$userId ','$cart_itemID ','$quantity', '$cart_total', '$currentdate','$status')";   
        $res = mysqli_query($conn, $sql1);
        if($res){
            echo'
            <script>
            alert("Order has been added to your cart!");
            window.location = \'../cart\';
            </script>';
        } 
        else{
            echo'<script>
            alert("Order failed to add to cart!");
            window.history.back(1);
            </script>';
        }   
    }
}
?>