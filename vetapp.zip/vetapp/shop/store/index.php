<?php 
include '../../shop/connection/database.php';
if(isset($_POST['addCart'])){
    $userID = $_POST['user_id'];
    $itemID = $_POST['item_id'];
    $quantity = $_POST['quantity'];
    $total = $_POST['total'];
    $status = "PENDING";

    // Check if the item already exists in the cart for the user
    $checkSql = "SELECT * FROM tbl_cart WHERE cart_userID = '$userID' AND cart_itemID = '$itemID' AND cart_Status = '$status'";
    $checkResult = mysqli_query($conn, $checkSql);
    if(mysqli_num_rows($checkResult) > 0) {
        // If the item already exists, update the quantity and total
        $cartRow = mysqli_fetch_assoc($checkResult);
        $newQuantity = $cartRow['cart_Quantity'] + $quantity;
        $newTotal = $cartRow['cart_Total'] + $total;

        $updateSql = "UPDATE tbl_cart SET cart_Quantity = '$newQuantity', cart_Total = '$newTotal' WHERE cart_userID = '$userID' AND cart_itemID = '$itemID'";
        $updateResult = mysqli_query($conn, $updateSql);
        if($updateResult){
            echo '<script>alert("Item quantity updated in cart."); window.location = \'index.php\';</script>';
        } else {
            echo '<script>alert("Failed to update item quantity in cart."); window.location = \'index.php\';</script>';
        }
    } else {
        // If the item doesn't exist, insert it into the cart
        $sqladd = "INSERT INTO `tbl_cart` (`cart_userID`,`cart_itemID`,`cart_Quantity`,`cart_Total`,`cart_Date`,`cart_Status`) VALUES ('$userID','$itemID','$quantity','$total','$currentdate','$status')";
        $results = mysqli_query($conn, $sqladd);
        if($results){
            echo '<script>alert("Item has been successfully added to cart."); window.location = \'index.php\';</script>';
        } else {
            echo '<script>alert("Failed to add item to cart."); window.location = \'index.php\';</script>';
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMC Animal Clinic - Store</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="../assets/css/store.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">


</head>
<body>
<?php
session_start();
if(isset($_SESSION['loggedin'])){
    require '../secondnav.php';
}
else{
    require '../firstnav.php';
}
?>

<div id = "items-main-container" class="container-sm">
    <h2 class="mb-3">Products</h2>
    <div class = "items-container">
        <?php 
        $sql = "SELECT * FROM tbl_items WHERE item_category = 'Products'";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $item_id = $row['item_ID'];
            $item_name = $row['item_Name'];
            $item_price = $row['item_Price'];
            $item_image = $row['item_Image'];
            $item_description = $row['item_Description'];

        ?>
        <div class="card">
            <img src="../../admin/admin/<?php echo $item_image ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo $item_name ?></h5>
                <p class="text-description card-text"><?php echo $item_description ?></p>
                <p class="card-text">₱<?php echo $item_price ?>.00</p>
                <button class="btn" data-bs-toggle="modal" data-bs-target="#addtoCart<?php echo $item_id?>">Add to Cart</button>
            </div>
        </div>
        <?php } ?>

    </div>


    <h2 class="mb-3">Services</h2>
    <div class = "items-container">
        <?php 
        $sql = "SELECT * FROM tbl_items WHERE item_category = 'Services'";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $item_id = $row['item_ID'];
            $item_name = $row['item_Name'];
            $item_price = $row['item_Price'];
            $item_image = $row['item_Image'];
            $item_description = $row['item_Description'];

        ?>
        <div class="card">
            <img src="../../admin/admin/<?php echo $item_image ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo $item_name ?></h5>
                <p class="text-description card-text"><?php echo $item_description ?></p>
                <p class="card-text"><?php echo $item_price ?>.00</p>
                <button class="btn" data-bs-toggle="modal" data-bs-target="#addtoCart<?php echo $item_id?>">Add to Cart</button>
            </div>
        </div>
        <?php } ?>

    </div>
</div>



<!-- Add Product Modal -->

<?php 
$sql = "SELECT * FROM tbl_items";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)){
    $item_id = $row['item_ID'];
    $item_name = $row['item_Name'];
    $item_price = $row['item_Price'];
    $item_image = $row['item_Image'];
    $item_description = $row['item_Description'];
?>
<div class="modal fade" id="addtoCart<?php echo $item_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add this to cart?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
           
                <form method="POST" action="index.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="user_id" value="<?php echo $userId?>">
                    <input type="hidden" name="item_id" value="<?php echo $item_id?>">
                   
                    <div class="form-group mb-3">
                        <label for="exampleInputEmail1">Quantity</label>
                        <input id="quantity<?php echo $item_id ?>" type="text" name="quantity" class="form-control" oninput="calculateTotal(<?php echo $item_id ?>)" placeholder="Quantity" onkeypress="if(event.keyCode<48 || event.keyCode>57)event.returnValue=false;" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="exampleInputEmail1">Price</label>
                        <input id="price<?php echo $item_id ?>" type="text" name="price" class="form-control" placeholder="Price" value="<?php echo $item_price ?>.00" readonly>
                    </div>

                    <div class="form-group mb-3">
                        <label for="exampleInputEmail1">Total</label>
                        <input id="total<?php echo $item_id ?>" type="text" name="total" class="form-control" placeholder="Total" value="<?php echo $item_price ?>.00" readonly>
                    </div>

                    <button type="submit" name="addCart" class="btn">ADD TO CART</button>

                </div>
                </form>
        </div>

        <script>
            function calculateTotal(itemId) {
                var quantity = parseFloat(document.getElementById('quantity' + itemId).value);
                var price = parseFloat(document.getElementById('price' + itemId).value);

                // If price is not provided, assume it's 0
                if (isNaN(price)) {
                    price = 0;
                }

                var total = quantity * price;

                // Check if quantity is a valid number
                if (!isNaN(total)) {
                    document.getElementById('total' + itemId).value = total.toFixed(2); // Adjust to your desired precision
                } else {
                    document.getElementById('total' + itemId).value = ""; // Clear the total if invalid input
                }
            }
</script>
    </div>
</div>

<?php } ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>