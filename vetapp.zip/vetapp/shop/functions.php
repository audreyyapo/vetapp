<?php 

include 'connection/database.php';

if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn, $_POST['loginusername']);
    $password = mysqli_real_escape_string($conn, $_POST['loginpassword']);
    
    $check_email = "SELECT * FROM tbl_users WHERE email = '$email' OR userName = '$email' AND userPassword = '$password'";
    $result = mysqli_query($conn, $check_email);
    
    if ($result && mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);
        $user_ID = $row['user_ID'];

        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['userId'] = $row['user_ID'];
        $_SESSION['email'] = $row['email']; // Store email once
        echo'
        <script>
            alert("You\'ve successfully logged in!");
        </script>
        ';
        header("Location: ../index.php?loginsuccess=true");
        exit; // Stop further execution after redirect
    }
    else if($result && mysqli_num_rows($result) < 1){
        echo'
        <script>alert("It looks like you\'re not yet a member! Click on the bottom link to sign up.");
        window.location = \'signin/index.php\';
        </script>
        ';
    }
    else{
        echo'
        <script>
            alert("Invalid Credentials");
            window.location = \'signin/index.php\';
        </script>
        ';
    }

    
    } else {
    // Handle case where login form was not submitted
    echo'
        <script>alert("Invalid Request");
        window.location = \'signin/index.php\';
        </script>
        ';
    }


 


?>