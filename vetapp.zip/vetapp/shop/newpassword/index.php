<?php
session_start();
include '../connection/database.php';

if (isset($_SESSION['password_reset_initiated']) && $_SESSION['password_reset_initiated'] == true) {
    $changepass = true;
    $userId = $_SESSION['userId'];
    $email = $_SESSION['email'];
  }
  
  else if (!isset($_SESSION['password_reset_initiated']) && $_SESSION['password_reset_initiated'] == false) {
    header("location:../signin/index.php");
  }
  
  else{
      header("location:../signin");
  }


    //if user click change password button
    if(isset($_POST['change-password'])){
        $password = $_POST['password'];
        $cpassword = $_POST['confirmpassword'];
        if($password !== $cpassword){
            echo '<script>alert("Confirm password not matched!")</script>';
        }else{
            $email = $_SESSION['email']; //getting this email using session
            $encpass = password_hash($password, PASSWORD_BCRYPT);
            $update_pass = "UPDATE tbl_users SET userPassword = '$encpass', userConfirmPassword = '$encpass' WHERE email = '$email'";
            $run_query = mysqli_query($conn, $update_pass);
            if($run_query){
                echo '<script>alert("Password has been successfully changed.");
                window.location = \'../signin\';
                </script>';
            }else{
                echo '<script>alert("Failed to change your password!")</script>';
                header('Location: ../newpassword');
            }
        }
    }
?>

<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title id="title">EMC Animal Clinic - New Password</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <!--For Icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <!--CSS-->
    <link rel="stylesheet" href="../assets/css/LoginRegister.css" media="screen">
    <link rel="stylesheet" href="../assets/css/navbar.css" media="screen">   
  </head>
  <body>
    <?php require '../firstnav.php'; ?>
    <!--Dito maglalagay ng content-->
    <section class="container-login">
        <div class ="login" id="frm" style = "height:300px;">
            <div class="card-image"></div>
            <h3>NEW PASSWORD</h3>
            <form action="" method="POST">
                        <div class="form-group1" style = "display:flex;">
                        <i id = "ics" class="fas fa-key fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="password" id = "userpass" class="form-control5" name="password" placeholder="New Password "  value="" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;"/>
                        <button type = "button" id = "show" onclick = "showpassword();"><i id = "for-show" class = "fas fa-eye"></i></button>
                        <button type = "button" id = "hide" onclick = "hidepassword();"hidden><i class="fa-solid fa-eye-slash" ></i></button>
                        </div>

                        <div class="form-group1" style = "display:flex;">
                        <i id = "ics" class="fas fa-key fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="password" id = "userpass1" class="form-control5" name="confirmpassword" placeholder="Confirm New Password "  value="" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;"/>
                        <button type = "button" id = "show1" onclick = "showpassword1();"><i id = "for-show" class = "fas fa-eye"></i></button>
                        <button type = "button" id = "hide1" onclick = "hidepassword1();"hidden><i class="fa-solid fa-eye-slash" ></i></button>
                        </div>
                        <div >
                           <center> <input type="submit"  id = "btnSubmit"  class="btnSubmit" name="change-password" value="Change Password" disabled = "disabled"></center>
                        </div>
            </form>
            </div> 
</section>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type = "text/javascript">
   (function(){
    document.querySelector("#btnSubmit").style.opacity = "0.4";
    $('form > div > input').keyup(function(){
        var empty = false;
        document.querySelector("#btnSubmit").style.opacity = "1";
        $('form > div > input').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.querySelector("#btnSubmit").style.opacity = "0.4";
            }
        });
        if(empty){
            $('#btnSubmit').attr ('disabled','disabled');
            
        }
        else{
            $('#btnSubmit').removeAttr ('disabled');
            
        }
    });


    var h = document.getElementById("userpass");
    document.getElementById("show").setAttribute("hidden","hidden");
        $('#userpass').keyup(function(){
    if (h.type === "password") {
     
        var empty = false;
        document.getElementById("show").removeAttribute("hidden");
        $('#userpass').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var empty = false;
        document.getElementById("hide").removeAttribute("hidden");
        $('#userpass').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("hide").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("hide").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide").removeAttribute("hidden");
            
        }
    }
});
    var hx = document.getElementById("userpass1");
    document.getElementById("show1").setAttribute("hidden","hidden");
        $('#userpass1').keyup(function(){
    if (hx.type === "password") {
     
       
        var empty = false;
        document.getElementById("show1").removeAttribute("hidden");
        $('#userpass1').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show1").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show1").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show1").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var empty = false;
        document.getElementById("hide1").removeAttribute("hidden");
        $('#userpass1').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("hide1").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("hide1").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide1").removeAttribute("hidden");
            
        }
    }

});
})()
</script>

<script>
    function showpassword() {
    var x = document.getElementById("userpass");
    if (x.type === "password") {
        x.type = "text";
        
    } else {
        x.type = "password";
    }
    document.getElementById("show").setAttribute("hidden","hidden");
    document.getElementById("hide").removeAttribute("hidden");
    }
    function hidepassword() {
    var y = document.getElementById("userpass");
    if (y.type === "password") {
        y.type = "text";
    } else {
        y.type = "password";
    }
    document.getElementById("show").removeAttribute("hidden");
    document.getElementById("hide").setAttribute("hidden","hidden");
    }


    function showpassword1() {
    var gx = document.getElementById("userpass1");
    if (gx.type === "password") {
        gx.type = "text";
        
    } else {
        gx.type = "password";
    }
    document.getElementById("show1").setAttribute("hidden","hidden");
    document.getElementById("hide1").removeAttribute("hidden");
    }
    function hidepassword1() {
    var xy = document.getElementById("userpass1");
    if (xy.type === "password") {
        xy.type = "text";
    } else {
        xy.type = "password";
    }
    document.getElementById("show1").removeAttribute("hidden");
    document.getElementById("hide1").setAttribute("hidden","hidden");
    }
</script>
</body>
</html>
