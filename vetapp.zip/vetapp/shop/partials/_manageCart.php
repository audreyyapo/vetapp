<?php
include '../connection/database.php';
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // dito nang gagaling yung user id sa session
    $userId = $_SESSION['userId'];
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
    {
        $attd = $_POST['cartsID'];
        $qty = $_POST['quantityItem'];
        $updatesql = "UPDATE `tbl_cart` SET `cart_Quantity`='$qty' WHERE `cart_ID`='$attd' AND `cart_userID`='$userId'";
        $updateresult = mysqli_query($conn, $updatesql);
    }
}
?>