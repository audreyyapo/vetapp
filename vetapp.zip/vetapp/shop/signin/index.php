

<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title id="title">EMC Animal Clinic - Login</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <!--For Icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <!--CSS-->
    <link rel="stylesheet" href="../assets/css/LoginRegister.css" media="screen">
    <link rel="stylesheet" href="../assets/css/navbar.css" media="screen">
   
  </head>
  <body>
    <?php require '../firstnav.php'; ?>
    <!--Dito maglalagay ng content-->
    <section class="container-login">
        <div class ="login" id="frm">
            <div class="card-image"></div>
            <h3>SIGN IN  </h3>
            <form action="../functions.php" method="POST">
           
                        <div class="form-group1">
                        <i id = "ics1" class="fas fa-envelope fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="text" id = "username" class="form-control5" name="loginusername" placeholder="Email"  required onkeypress="if(event.keyCode==32)event.returnValue=false;"  style="padding-left:43px;">  
                        </div>
                        <div class="form-group1" style = "display:flex;">
                        <i id = "ics" class="fas fa-key fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="password" id = "userpass" class="form-control5" name="loginpassword" placeholder="Password "  value="" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;"/>
                        <button type = "button" id = "show" onclick = "showpassword();"><i id = "for-show" class = "fas fa-eye"></i></button>
                        <button type = "button" id = "hide" onclick = "hidepassword();"hidden><i class="fa-solid fa-eye-slash" ></i></button>
                        </div>
                        <div class="form-group3">
                            <a href="../forgotpassword/" class="ForgetPwd">Forget Password?</a>
                        </div>
                        <div >
                           <center> <input type="submit"  id = "btnSubmit"  class="btnSubmit" name="login" value="Login" disabled = "disabled"></center>
                        </div>
                       
                        <center><div class="form-group2"><p >Don't have an account? <a href="../signup" class="reg">Register Here</a></p></center>
                        </div>
                    </form>
            </div> 
</section>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type = "text/javascript">
   (function(){
    document.querySelector("#btnSubmit").style.opacity = "0.4";
    $('form > div > input').keyup(function(){
        var empty = false;
        document.querySelector("#btnSubmit").style.opacity = "1";
        $('form > div > input').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.querySelector("#btnSubmit").style.opacity = "0.4";
            }
        });
        if(empty){
            $('#btnSubmit').attr ('disabled','disabled');
            
        }
        else{
            $('#btnSubmit').removeAttr ('disabled');
            
        }
    });


    var h = document.getElementById("userpass");
    document.getElementById("show").setAttribute("hidden","hidden");
        $('#userpass').keyup(function(){
    if (h.type === "password") {
     
       
        var empty = false;
        document.getElementById("show").removeAttribute("hidden");
        $('#userpass').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var empty = false;
        document.getElementById("hide").removeAttribute("hidden");
        $('#userpass').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("hide").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("hide").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide").removeAttribute("hidden");
            
        }
    }
});
})()
</script>

<script>
    function showpassword() {
    var x = document.getElementById("userpass");
    if (x.type === "password") {
        x.type = "text";
        
    } else {
        x.type = "password";
    }
    document.getElementById("show").setAttribute("hidden","hidden");
    document.getElementById("hide").removeAttribute("hidden");
    }
    function hidepassword() {
    var y = document.getElementById("userpass");
    if (y.type === "password") {
        y.type = "text";
    } else {
        y.type = "password";
    }
    document.getElementById("show").removeAttribute("hidden");
    document.getElementById("hide").setAttribute("hidden","hidden");
    }
</script>
</body>
</html>