<?php 
include '../connection/database.php';
date_default_timezone_set('Asia/Manila');
$today = date('y-m-d');

$errors = array();
//if user signup button
if(isset($_POST['signup'])){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);


    if($password !== $cpassword){
        $errors['passnot'] = "Password does not match";
        // Handle error here, perhaps redirect back to the registration page
        exit();
    }
    // Check if username or email already exists
    $check_query = "SELECT * FROM tbl_users WHERE userName = '$username' OR email = '$email'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $row = mysqli_fetch_assoc($check_result);
        if ($row['userName'] === $username) {
            $errors['username'] = "Username is already existed!";
        }
        if ($row['email'] === $email) {
            $errors['email'] = "Entered email is already existed!";
        }
    } else {
        // If no errors, proceed with insertion
        $encpass = password_hash($password, PASSWORD_BCRYPT);
        $insert_data = "INSERT INTO tbl_users (`userName`, `firstName`, `lastName`, `email`, `contactNumber`, `gender`,`user_Address`, `userPassword`, `userConfirmPassword`)
                        VALUES ('$username', '$firstName', '$lastName', '$email', '$phone', '$gender','$address' ,'$encpass', '$encpass')";
        $query = mysqli_query($conn, $insert_data);
        if($query){
            echo "<script>alert('Registration Successful!')</script>";
            echo "<script>window.location.href = '../signin'</script>";
            exit();
        } else {
            echo "<script>alert('Registration Failed!')</script>";
        }
    }
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <title id="title">EMC Animal Clinic - Register</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <!--For Icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <!--CSS-->
    <link rel="stylesheet" href="../assets/css/LoginRegister.css" media="screen">
    <link rel="stylesheet" href="../assets/css/navbar.css" media="screen">

  </head>
  <body>
  <?php require '../firstnav.php'; ?>
    <!--Dito maglalagay ng content-->
    <section id = "container-register" class="container-register">
    <div class ="register">
            <div class="card-image"></div>
            <h3>SIGN UP</h3>
            <form method="POST" action="index.php">
           
                    <ul id ="first-ul">
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="username">Username</label></b></div>
                        <i id = "regs" class="fas fa-user fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="text" class="form-control" placeholder="Username"  name="username" required maxlength="20" minlength="8" onkeypress="if(event.keyCode==32)event.returnValue=false;" style="font-size:15px;">
                            <p id = "error-message" class = "text-danger"><?php if(isset($errors['username'])) echo $errors ['username']; ?></p>
                        </div>
                        </li>
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="firstName">First Name</label></b></div>
                        <i id = "regs" class="fas fa-user fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="text" class="form-control" placeholder="First Name" name="firstName" required="true" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;"style="font-size:15px;">
                        </div>
                        </li>
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="lastName">Last Name</label></b></div>
                        <i id = "regs" class="fas fa-user fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="text" class="form-control" placeholder="Last Name" name="lastName" required="true" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" style="font-size:15px;">
                        </div>
                        </li>
                    </ul>
                    <ul id="second-ul">
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="email">Email</label></b></div>
                        <i id = "regs" class="fas fa-envelope fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="email" id="eml" class="form-control" placeholder="Email " name="email" required onkeypress="if(event.keyCode==32)event.returnValue=false;"  style="padding-left:43px;font-size:13px;">
                            <p id = "error-message" class = "text-danger"><?php if(isset($errors['email'])) echo $errors ['email']; ?></p>

                        </div>
                        </li>
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="phone">Contact Number</label></b></div>
                        <i id = "regs" class="fas fa-phone fa-lg fa-fw" aria-hidden="true"></i>  
                            <input type="text" id="phone" class="form-control" placeholder="09123456789 " name="phone" required pattern="[0-9]{11}" maxlength="11" onkeypress="if(event.keyCode<48 || event.keyCode>57)event.returnValue=false;" style="font-size:15px;">
                       <p id = "error-message" class = "text-danger"><?php if(isset($errors['number'])) echo $errors ['number']; ?></p>
                        </div>
                        </li>
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="gender">Gender</label></b></div>
                        <i id = "regs" class="fas fa-user fa-lg fa-fw" aria-hidden="true"></i>
                        <input type="text" id="gender" class="form-control" placeholder="Female or Male " name="gender" required onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" style="font-size:15px;">
                        </div>
                        </li>
                    </ul>
                    <ul style = "width:100%;">
                        <li id = "for-address-style">
                        <div class="form-group">
                        <div class="labels"><b><label for ="address">Address</label></b></div>
                        <i id = "regs" class="fas fa-location-dot fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="text" class="form-control" placeholder="Address"  name="address" required style="width:100%;font-size:15px;">
                        </div>
                        </li>
                    </ul>
                    <ul id="third-ul">
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="password">Password</label></b></div>
                            <div style = "display:flex;">
                            <i id = "regs" class="fas fa-key fa-lg fa-fw" aria-hidden="true"></i>
                            <input id = "pass1" type="password"  class="form-control" placeholder="Password " name="password" minlength="8" maxlength="" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;" style="font-size:15px;">
                            <button type = "button" id = "show2" onclick = "showpassword2();"><i id = "for-show" class = "fas fa-eye"></i></button>
                            <button type = "button" id = "hide2" onclick = "hidepassword2();"hidden><i class="fa-solid fa-eye-slash" ></i></button>
                            </div>
                            <p id = "error-message" class = "text-danger"><?php if(isset($errors['passnot'])) echo $errors ['passnot']; ?></p>

                          </div>
                        </li>
                        <li>
                        <div class="form-group">
                        <div class="labels"><b><label for ="password">Confirm Password</label></b></div>
                            <div style = "display:flex;">
                            <i id = "regs" class="fas fa-key fa-lg fa-fw" aria-hidden="true"></i>
                            <input id = "pass2" type="password" class="form-control" placeholder="Confirm Password "  minlength="8" maxlength="" name="cpassword" required="true" onkeypress="if(event.keyCode==32)event.returnValue=false;" style="font-size:15px;">
                            <button type = "button" id = "show3" onclick = "showpassword3();"><i id = "for-show" class = "fas fa-eye"></i></button>
                            <button type = "button" id = "hide3" onclick = "hidepassword3();"hidden><i class="fa-solid fa-eye-slash" ></i></button>
                            </div>
                            <p id = "error-message" class = "text-danger"><?php if(isset($errors['passnot'])) echo $errors ['passnot']; ?></p>

                          </div>
                       

                        </li>
                    </ul>
                        <div class="form-group2 mt-1">
                            <center><input type="submit" class="btnSubmit" name="signup" id ="btn" value="Submit" /></center>
                        </div>
                        <center> <div class="form-group3"><p >Already have an account? <a href="../signin" class="reg">Login Here</a></p></center>
                        </div>
                        </form>
        </div>

        
</section>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type = "text/javascript">
   (function(){
    document.getElementById("show2").setAttribute("hidden","hidden");
    $('#pass1').keyup(function(){
        var empty = false;
        document.getElementById("show2").removeAttribute("hidden");
        $('#pass1').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show2").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show2").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show2").removeAttribute("hidden");
            
        }
    });



    var h = document.getElementById("pass1");
    document.getElementById("show2").setAttribute("hidden","hidden");
        $('#pass1').keyup(function(){
    if (h.type === "password") {
     
       
        var empty = false;
        document.getElementById("show2").removeAttribute("hidden");
        $('#pass1').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show2").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show2").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show2").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var empty = false;
        document.getElementById("hide2").removeAttribute("hidden");
        $('#pass1').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("hide2").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("hide2").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide2").removeAttribute("hidden");
            
        }
    }
});



var j = document.getElementById("pass2");
    document.getElementById("show3").setAttribute("hidden","hidden");
        $('#pass2').keyup(function(){
    if (j.type === "password") {
     
       
        var emptys = false;
        document.getElementById("show3").removeAttribute("hidden");
        $('#pass2').each(function(){
            if($(this).val()== ''){
                emptys = true;
                document.getElementById("show3").setAttribute("hidden","hidden");
            }
        });
        if(emptys){
            document.getElementById("show3").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show3").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var emptys = false;
        document.getElementById("hide3").removeAttribute("hidden");
        $('#pass2').each(function(){
            if($(this).val()== ''){
                emptys = true;
                document.getElementById("hide3").setAttribute("hidden","hidden");
            }
        });
        if(emptys){
            document.getElementById("hide3").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide3").removeAttribute("hidden");
            
        }
    }
});
})()
    
</script>
<script>
    function showpassword2() {
    var x = document.getElementById("pass1");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
    document.getElementById("show2").setAttribute("hidden","hidden");
    document.getElementById("hide2").removeAttribute("hidden");
    }
    function hidepassword2() {
    var y = document.getElementById("pass1");
    if (y.type === "password") {
        y.type = "text";
    } else {
        y.type = "password";
    }
    document.getElementById("show2").removeAttribute("hidden");
    document.getElementById("hide2").setAttribute("hidden","hidden");
    }
    function showpassword3() {
    var x = document.getElementById("pass2");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
    document.getElementById("show3").setAttribute("hidden","hidden");
    document.getElementById("hide3").removeAttribute("hidden");
    }
    function hidepassword3() {
    var y = document.getElementById("pass2");
    if (y.type === "password") {
        y.type = "text";
    } else {
        y.type = "password";
    }
    document.getElementById("show3").removeAttribute("hidden");
    document.getElementById("hide3").setAttribute("hidden","hidden");
    }

   
</script>
<script>
       function exitbutton(){
        var exitname = document.getElementById("errors").style.display = "none";
       }
       setTimeout("exitbutton()",5000);
        </script>
</body>
</html>
<style>
  #error-message{
    color:red;
    font-size:13px;
  }
</style>
