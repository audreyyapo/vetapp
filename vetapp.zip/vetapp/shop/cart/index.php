<?php 
error_reporting(1); 
session_start();
include '../../shop/connection/database.php';
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>EMC Animal Clinic - Cart</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <link rel="stylesheet" href="../assets/css/cart.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

</head>
<body style ="background:whitesmoke;">
<?php require '../secondnav.php' ?>
<!--?>-->
  <!-- DELETE POP UP FORM (Bootstrap MODAL) -->
  <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Remove all items</h5>
                </div>
                <form action="functions.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="delete_id" id="delete_id">
                        <h4> Are you sure you want to remove all?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="removeAllItem" class="btn btn-primary"> YES </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class = "cart-container-main" style = "margin-top:130px;">
    <div id = "cont" class = "cart-container-sub">
        <div class = "for-title">
                <center><h2>My Cart</h2></center>
            </div>
            <div class = "for-cart-content-main">
            <div class = "for-cart-content">
<?php
$sql = "SELECT * FROM tbl_cart WHERE `cart_userID`= '$userId' AND cart_Status ='PENDING'";
$result = mysqli_query($conn, $sql);
$counter = 0;
$totalPrice = 0;
$totalQuantity = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $cartID = $row['cart_ID'];
    $Quantity = $row['cart_Quantity'];
    $cartTotal = $row['cart_Total'];
    $cart_itemID = $row['cart_itemID'];
   
    $sqlname = "SELECT * FROM tbl_items WHERE item_ID = '$cart_itemID'";
    $sqlres = mysqli_query($conn, $sqlname);
    $rowname =  mysqli_fetch_array($sqlres);

    $image = $rowname['item_Image'];
    $itemName = $rowname['item_Name'];
    $itemPrice = $rowname['item_Price'];

    $total = $itemPrice * $Quantity;
    $counter++;
    $totalPrice =  $totalPrice +  $total;
    $totalQuantity += $Quantity;

?>
              
                <div class = "for-cart">
                    <div class = "cart-items">
                        <div class = "for-image">
                            <img src="../../admin/assets/<?php echo $image ?>">
                        </div>
                        <div class = "for-button-items">
                        <div class = "remove-button">
                                <form method="POST" action="functions.php">  
                                    <input type="hidden" name="itemIds" value="<?php echo $cartID?>">
                                    <button id = "removed" type="type" name="removeItem" class="remove btn btn-danger"><i class="fa-solid fa-trash"></i> REMOVE</button>
                                </form>
                            </div>
                            <div class = "for-items">
                                <br><br>
                                <p id = "for-name"><?php echo $itemName ?></p>
                                <br>
                                <p id="for-price">₱ <?php echo $itemPrice?>.00</p>
                                <br>
                                <div class="quantity">

                            <form id ="frm<?php echo $cartID?>">
                            <input type="hidden" name="cartsID" value="<?php echo $cartID?>">
                        Quantity <input type="number" id = "quantity<?php echo $cartID?>" name="quantityItem" min = "1" value="<?php echo $Quantity ?>" class="text-center input-qty" style="" required onchange="updateCart(<?php echo $cartID?>)" max = "30" onkeyup="return false"  oninput="inputscheck(<?php echo $cartID?>);" onClick="this.select();">
                            </form>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php  }

                if ($counter == 0) {?>
                <script>
                    document.getElementById("cont").innerHTML =
                        '<div class="col-md-12 my-5" style=""><div class="card" style = "background:transparent;outline:none;border:none;"><div class="card-body cart"><div class="col-sm-12 empty-cart-cls text-center"> <img src="https://cdn3.iconfinder.com/data/icons/food-delivery-aesthetics-vol-2/256/No_Online_Orders-512.png" style = "width:200px;height:200px;" class="img-fluid mb-4 mr-3"><h3><strong>No orders Yet!</strong></h3><h4>Your cart is empty. Add something from the store.</h4> <a href="../store/index.php" class="btn cart-btn-transform m-3" data-abc="true" style = "background:black;color:white;">Go to Store</a> </div></div></div></div>';
                </script>
                <?php }?>
                </div>
           
                <div class = "for-checkout-main">
                <div class = "for-checkout">
                        <div class="cart-items-cont">
                                <p class="for-price-footer">Total:</p>
                                <p class="for-price-checkout">₱ <?php echo $totalPrice ?>.00</p>
                        </div>
                        <div class = "for-proceed">
                            <a href="checkoutItems.php?cartid=<?php echo $cartID ?>&total=<?php echo $totalPrice ?>&quantity=<?php echo $totalQuantity ?>">
          
                            <button id = "btn-checkout" type="button" class="btn"$ans>PROCEED TO CHECKOUT</button>
                            </a> 
                        </div>
                        <div class = "for-removeall">
                                        
                            <input type="hidden" name="userId" value="<?php $userId = $_SESSION['userId']; echo $userId ?>">  
                            <button id = "btn-remove" type="button" class="btn btn-danger deletebtn"  name=""><i class="fa-solid fa-trash"></i> REMOVE ALL</button>
                            <input id = "count-hidden" type = "text" value ="<?php echo $count ?>" hidden >


                        </div>
                </div>
                </div>
            </div>
        </div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<script>
    $(document).ready(function () {

    $('.deletebtn').on('click', function () {
        $('#deletemodal').modal('show');
    });
    });
</script>
    
<script>
function inputscheck(id){
    var checks = document.getElementById("quantity" + id).value;
    if(checks>30){
        alert("The maximum order for this item is 30.");
            document.getElementById("quantity" + id).value = 30;
    }
}             
function check(input) {
    if (input.value <= 0) {
    }
    else if(input.value > 30){
        alert("The maximum order for this item is 30.");
        input.value = 30;
    }
}

function updateCart(id) {
var checks = document.getElementById("quantity" + id).value;
if(checks<=0){
    document.getElementById("quantity" + id).value = 1;
}
    $.ajax({
    url: '../partials/_manageCart.php',
    type: 'POST',
    data: $("#frm" + id).serialize(),
    success: function(res) {
    location.reload();
    }
    })
}
    </script>
   

</body>
</html>