<?php

include '../../shop/connection/database.php';
session_start();
$userId = $_SESSION['userId'];
if($_SERVER["REQUEST_METHOD"] == "POST") {
    //Remove ITEM
    if(isset($_POST['removeItem'])) {
        $itemId = $_POST["itemIds"];
        $sql = "DELETE FROM `tbl_cart` WHERE `cart_ID`='$itemId' AND `cart_userID`='$userId'";   
        $result = mysqli_query($conn, $sql);
        session_start();
        $_SESSION['status'] = "Item has been removed from your cart!";
        echo'<script>
        window.location=document.referrer;</script>"';
      
    }

    //Remove ALL ITEM
    if(isset($_POST['removeAllItem'])) {
        $sql = "DELETE FROM `tbl_cart` WHERE `cart_userID`='$userId' AND cart_Status = 'PENDING'";   
        $result = mysqli_query($conn, $sql);
        session_start();
        $_SESSION['status'] = "All Items has been removed from your cart!";
        echo'<script>
        window.location=document.referrer;</script>"';
    }
    if(isset($_POST['checkout'])){
        // Check if address is empty
        if(empty($_POST['address'])) {
            echo "<script>alert('Please enter your delivery address')</script>";
        } else {
            $currentDates = date('Ymd'); // Get current date in YYYYMMDD format
            $currentDay = date('N'); // Get current day (1 for Monday, 7 for Sunday)
    
            // Generate a random number between 1000 and 9999
            $randomNumber = mt_rand(1000, 9999);
    
            // Concatenate current date, day, and random number to form the reference number
            $refNo = $currentDates . $currentDay . $randomNumber;
            $delivery = $_POST['deliveryfee'];
            $address = mysqli_real_escape_string($conn, $_POST['address']);
            $totalPrice = $_POST['total'];
            $subTotal = $_POST['subtotal'];
            $status = "PENDING";
            $cod = $_POST['cashondelivery'];
            $cartid = $_POST['cart_id'];
            $date = $_POST['date'];
    
            // Proceed with the order insertion

            $insert_data = "INSERT INTO tbl_order (`user_ID`, `order_subtotal`, `order_delivery`,`order_mode`,`order_total`,`order_Address`, `order_refNo`, `order_startDate`,`order_finishDate`,`order_Status`)
                            VALUES ('$userId', '$subTotal', '$delivery', '$cod', '$totalPrice', '$address' ,'$refNo', '$date', '', '$status')";
            $query = mysqli_query($conn, $insert_data);
            $orderId = $conn->insert_id;

            if($query){
                echo "<script>alert('Order Successfully')</script>";

            $select = "SELECT * FROM tbl_cart WHERE cart_userID = '$userId' and cart_Status = 'PENDING' ";
            $sqlrr = mysqli_query($conn, $select);
            while($row = mysqli_fetch_array($sqlrr)){
            $cartID = $row['cart_ID'];

            $itemSql = "INSERT INTO `tbl_orderitems` (`order_itemsID`, `order_cartID`) VALUES ('$orderId', '$cartID')";
            $itemResult = mysqli_query($conn, $itemSql);
            }
            $deletesql = "UPDATE `tbl_cart` SET cart_Status = 'ONGOING' WHERE `cart_userID`='$userId'";   
            $deleteresult = mysqli_query($conn, $deletesql);

            $sqlnotif = mysqli_query($conn, "INSERT INTO tbl_notif (notif_cartID, notif_dateTime) VALUE ('$orderId','$date')");

                echo "<script>window.location.href = '../vieworder'</script>";
                exit();
            } else {
                echo "<script>alert('Order Failed!');
                window.location=document.referrer;</script>";
                
            }
        }
    }
}

?>

