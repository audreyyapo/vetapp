<?php 
error_reporting(1); 
session_start();
include '../../shop/connection/database.php';

$myId = $_SESSION['userId'];
$cartid = $_GET['cartid'];
$subtotal = $_GET['total'];
$totalquantity = $_GET['quantity'];

$delivery = 50;

$totalprice = $subtotal + $delivery;

$sqlprof = "SELECT * FROM tbl_users WHERE user_ID = '$myId'";
$sqlres = mysqli_query($conn,$sqlprof);
$row = mysqli_fetch_assoc($sqlres);


$fname = $row['firstName'];
$lname = $row['lastName'];
$address =$row['user_Address'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMC Animal Clinic - Checkout</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <link rel="stylesheet" href="../assets/css/checkoutitems.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
</head>
<body>
<?php require '../secondnav.php' ?>

<div class = "checkout-header container-fluid">
        <div class = "for-title container-sm">
            <center><h2>CHECKOUT</h2></center>
        </div>
    </div>
<div class = "checkout-container container-fluid">
    <div class = "check container-sm">
    <form action="functions.php" method="POST" class = "mt-5">
        <div class = "row">
            <div class="col-md-6">
                <label class="small mb-1" for="inputFirstName">First name</label>
                <input class="form-control" style = "opacity:0.6;background:#000;color:#fff;" id="inputFirstName" name="fname" type="text" placeholder="Enter your first name" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" value="<?php echo $fname?>" readonly>
            </div>
                                            
            <div class="col-md-6">
                <label class="small mb-1" for="inputLastName">Last name</label>
                <input class="form-control" style = "opacity:0.6;background:#000;color:#fff;" id="inputLastName" name="lname" type="text" placeholder="Enter your last name" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" value="<?php echo $lname?>" readonly>
            </div>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Enter Address:</label>
            <input type="text" class="form-control" name = "address" value="<?php echo $address?>" required>
        </div>

        <div class="form-check">
            <input class="form-check-input" type="radio" name="cashondelivery" value="COD" id="cashondelivery" checked>
            <label class="form-check-label" for="cashondelivery">CASH ON DELIVERY</label>
        </div>
        <hr/>
        <div class = "order-summary">
                <h6>ORDER SUMMARY</h6>
                <div class = "computation-container">
                    <div class = "computations" >
                        <p>No. of Items:</p>
                        <p><?php echo $totalQuantity ?></p>
                    </div>
                    <div class = "computations" >
                        <p>Sub Total:</p>
                        <p>₱<?php echo $subtotal ?>.00</p>
                    </div>
                    <div class = "computations" >
                        <p>Delivery Fee:</p>
                        <p>₱<?php echo $delivery ?>.00</p>
                    </div>
                    <hr/>
                    <div class = "computations" >
                        <p class = "total">Total:</p>
                        <p class = "total">₱<?php echo $totalprice ?>.00</p>
                    </div>
                </div>
        </div>
        <input type = "hidden" name = "deliveryfee" value = "<?php echo $delivery ?>"/>
        <input type = "hidden" name = "total" value = "<?php echo $totalprice ?>"/>
        <input type = "hidden" name = "subtotal" value = "<?php echo $subtotal ?>"/>
        <input type = "hidden" name = "cart_id" value = "<?php echo $cartid ?>"/>
        <input type = "hidden" name = "date" value = "<?php echo $currentdate ?>"/>
        <div id = "checkouts">
        <button type="submit" name = "checkout" class="btn">Submit</button>
        </div>
    </form>
    
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>