<?php 
session_start();
include '../connection/database.php';
//if user click continue button in forgot password form
if(isset($_POST['check-email'])){
    $emails = mysqli_real_escape_string($conn, $_POST['email']);
    $sqlexist= "SELECT * FROM tbl_users WHERE email = '$emails'";
    $result = mysqli_query($conn, $sqlexist);
    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);
        $user_ID = $row['user_ID'];
        session_start();
        $_SESSION['password_reset_initiated'] = true;
        $_SESSION['userId'] = $user_ID;
        $_SESSION['email'] = $emails; // Store email once
        header("Location: ../newpassword/index.php");
        exit();
    }
    else{
        echo'
        <script>alert("It looks like you\'re not yet a member! Proceed to Login Page and click on the bottom link to sign up.");
        window.location = \'../signin/index.php\';
        </script>
        ';
}
}

?>

<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title id="title">EMC Animal Clinic - Forgot Password</title>
    <link rel = "icon" href ="../assets/images/vetapp-logo.jpeg" type = "image/x-icon">
    <!--For Icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <!--CSS-->
    <link rel="stylesheet" href="../assets/css/LoginRegister.css" media="screen">
    <link rel="stylesheet" href="../assets/css/navbar.css" media="screen">
   
  </head>
  <body>
    <?php require '../firstnav.php'; ?>
    <!--Dito maglalagay ng content-->
    <section class="container-login">
        <div class ="login" id="frm"  style="height:250px;">
            <div class="card-image"></div>
            <h3>FORGOT PASSWORD</h3>
            <form action="" method="POST">
                        <div class="form-group1">
                        <i id = "ics1" class="fas fa-envelope fa-lg fa-fw" aria-hidden="true"></i>
                            <input type="text" id = "username" class="form-control5" name="email" placeholder="Email"  required onkeypress="if(event.keyCode==32)event.returnValue=false;"  style="padding-left:43px;">  
                        </div>
                        <div >
                           <center> <input type="submit"  id = "btnSubmit"  class="btnSubmit" name="check-email" value="Forgot Password" disabled = "disabled"></center>
                        </div>
                       
                        </div>
                    </form>
            </div> 
</section>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type = "text/javascript">
   (function(){
    document.querySelector("#btnSubmit").style.opacity = "0.4";
    $('form > div > input').keyup(function(){
        var empty = false;
        document.querySelector("#btnSubmit").style.opacity = "1";
        $('form > div > input').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.querySelector("#btnSubmit").style.opacity = "0.4";
            }
        });
        if(empty){
            $('#btnSubmit').attr ('disabled','disabled');
            
        }
        else{
            $('#btnSubmit').removeAttr ('disabled');
            
        }
    });


    var h = document.getElementById("userpass");
    document.getElementById("show").setAttribute("hidden","hidden");
        $('#userpass').keyup(function(){
    if (h.type === "password") {
     
       
        var empty = false;
        document.getElementById("show").removeAttribute("hidden");
        $('#userpass').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var empty = false;
        document.getElementById("hide").removeAttribute("hidden");
        $('#userpass').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("hide").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("hide").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide").removeAttribute("hidden");
            
        }
    }
});
})()
</script>
</body>
</html>