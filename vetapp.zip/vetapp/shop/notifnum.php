<?php   
include 'connection/database.php';
session_start();
$userId = $_SESSION['userId'];

$sqlpending = mysqli_query($conn,"SELECT * FROM tbl_usernotif WHERE user_ID = '$userId' AND notif_status='0'");
$totalpending = mysqli_num_rows($sqlpending); 
if($totalpending == 0){
$hidden = "hidden";
}
                                   
?>
<p id = "notif-count" <?php echo $hidden?>><?php echo $totalpending ?> </p>
