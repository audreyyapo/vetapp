<?php 
include 'connection/database.php';
session_start();
$userId = $_SESSION['userId'];


$sqlnotif = mysqli_query($conn, "SELECT * FROM `tbl_usernotif` WHERE user_ID = '$userId' ORDER BY notif_ID DESC LIMIT 5 ");
while($sqlnt = mysqli_fetch_array($sqlnotif)){
    $notifcart = $sqlnt['notif_cartID'];
    $orderstatus = $sqlnt['notif_orderstatus'];
    $orderID = $sqlnt['order_ID'];

    $sqlno = mysqli_query($conn, "SELECT * FROM `tbl_order` WHERE order_ID = '$orderID'");
    $sqlntt = mysqli_fetch_array($sqlno);
    $userid = $sqlntt['user_ID'];
    $refNo = $sqlntt['order_refNo'];
?>
<a id = "notif" href="#" class="dropdown-item" style = "padding:0;">
    <a id ="main-a" href="../vieworder">
    <p id = "new-order"class="fw-normal" ><?php echo $orderstatus?>
    <br><?php echo $refNo ?></p></a>
</a>
<?php
 } ?>

 <style>
    #main-a,
    #notif{
        text-decoration:none;
        margin:0;
        padding:0;
    }
    #new-order{
        margin:0;
        color:black;
        text-align:center;
        padding:0 5px;
        font-size:15px;
        border-bottom: 1px solid #313131;

    }
    #new-order:hover{
        color:black;
        background:#bababa;
    }
@media(max-width:998px){
    #new-order{
        padding:0;
        font-size:13px;

    }
}
</style>
