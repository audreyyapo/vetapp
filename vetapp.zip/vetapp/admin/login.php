<?php

    include 'assets/database.php';
    $username = $_POST["username"];
    $password = $_POST["password"]; 
    $password1 = md5($password);  
    
    $sql = "SELECT * FROM adminuser where adminUsername='$username' and adminPassword='$password1'"; 
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);


  if($num == true){
    $row=mysqli_fetch_assoc($result);
    $userId = $row['ID'];
            if($result){ 
                session_start();
                $_SESSION['adminuserId'] = $userId;
                $_SESSION['adminloggedin'] = true;
                $_SESSION['adminusername'] = $username;
                
                header("location: dashboard/index.php?loginsuccess=true");
                exit();
            } 
            else  {
                header("location: admin/login.php?loginsuccess=false");
            }
    } 
 
  
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <title>EMC Animal Clinic - VET App</title>
    <link rel = "icon" href ="assets/img/vetapp-logo.jpeg" type = "image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel = "stylesheet" href = "assets/css/login.css">


</head>
<body>
    <main id="main" class="bg-dark d-flex flex-row flex-wrap">
        <div id="login-left">
            <div class="logo">
                <img src="assets/img/vetapp-logo.jpeg" alt="EMC Animal Clinic" style = "height:300px;width:300px;margin-left:-30px;">
            </div>
        </div>
        <div id="login-right">
        <div class="card col-md-8">
            <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                <center><h4>LOGIN</h4>
                <label class="control-label"><b>ADMINISTRATOR</b></label></center><br>
                <input type="text" id="username" name="username" class="form-control" placeholder="Username">
                </div>
                <div class="form-group" style = "display:flex;">
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" onkeypress="if(event.keyCode==32)event.returnValue=false;">
                <button type = "button" id = "show" onclick = "showpassword();"><i id = "for-show" class = "fas fa-eye"></i></button>
                <button type = "button" id = "hide" onclick = "hidepassword();"hidden><i class="fa-solid fa-eye-slash" ></i></button>

                </div>
                <center><button id = "btnSubmit" type="submit" class="btn-sm btn-block btn-wave col-md-4" style="background-color:black;color:whitesmoke;font-size:19px;">Login</button></center>
            </form>
            </div>
        </div>
        </div>
    </main>  

    <?php
        if(isset($_GET['loginsuccess']) && $_GET['loginsuccess']=="false"){
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Warning!</strong> Invalid Credentials
                <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span></button>
                </div>';
        }
    ?>
   

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
    
<script type = "text/javascript">
   (function(){
    document.querySelector("#btnSubmit").style.opacity = "0.4";
    $('form > div > input').keyup(function(){
        var empty = false;
        document.querySelector("#btnSubmit").style.opacity = "1";
        $('form > div > input').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.querySelector("#btnSubmit").style.opacity = "0.4";
            }
        });
        if(empty){
            $('#btnSubmit').attr ('disabled','disabled');
            
        }
        else{
            $('#btnSubmit').removeAttr ('disabled');
            
        }
    });


    var h = document.getElementById("password");
    document.getElementById("show").setAttribute("hidden","hidden");
        $('#password').keyup(function(){
    if (h.type === "password") {
     
       
        var empty = false;
        document.getElementById("show").removeAttribute("hidden");
        $('#password').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("show").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("show").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("show").removeAttribute("hidden");
            
        }
   
    } 
    else{
        var empty = false;
        document.getElementById("hide").removeAttribute("hidden");
        $('#password').each(function(){
            if($(this).val()== ''){
                empty = true;
                document.getElementById("hide").setAttribute("hidden","hidden");
            }
        });
        if(empty){
            document.getElementById("hide").setAttribute("hidden","hidden");
            
        }
        else{
            document.getElementById("hide").removeAttribute("hidden");
            
        }
    }
});
})()
</script>

<script>
    function showpassword() {
    var x = document.getElementById("password");
    if (x.type === "password") {
        x.type = "text";
        
    } else {
        x.type = "password";
    }
    document.getElementById("show").setAttribute("hidden","hidden");
    document.getElementById("hide").removeAttribute("hidden");
    }
    function hidepassword() {
    var y = document.getElementById("password");
    if (y.type === "password") {
        y.type = "text";
    } else {
        y.type = "password";
    }
    document.getElementById("show").removeAttribute("hidden");
    document.getElementById("hide").setAttribute("hidden","hidden");
    }
</script>
</body>
</html>