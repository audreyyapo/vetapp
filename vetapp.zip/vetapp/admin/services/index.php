<?php 
 include ('../assets/database.php');
 session_start();

 if(isset($_POST['addProduct'])){
    $productname = $conn->real_escape_string($_POST['productname']);
    $desc = $conn->real_escape_string($_POST['desc']);
    $price = $_POST['price'];
    $category = "Services";
    $name = $_FILES['file']['name'];
    $fileExt = explode('.', $name);
    $fileActualExt = strtolower(end($fileExt));
    $target_dir = "../assets/img/items/";
    $target_file = $target_dir . $name;
    $extensions_arr = array("jpg", "png", "jpeg");

    // Check if the product name already exists
    $sql_check = "SELECT * FROM tbl_items WHERE item_Name = '$productname'";
    $result_check = mysqli_query($conn, $sql_check);
    if (mysqli_num_rows($result_check) > 0) {
        // Product name already exists
        echo '<script>alert("Product name already exists! Please choose a different name.");
              window.location = \'index.php\';</script>';
        exit(); // Exit script if product name already exists
    }

    if (in_array($fileActualExt, $extensions_arr)) {
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {

            $sql1 = "SELECT * FROM tbl_category WHERE categoryName = '$category'";
            $sqlres = mysqli_query($conn, $sql1);
            $row = mysqli_fetch_assoc($sqlres);
            $categoryID = $row['ID'];

            $sqladd = "INSERT INTO `tbl_items` (`item_Image`,`item_Name`, `item_Description`,`item_Price`,`item_category`,`item_CategoryID`) 
                       VALUES ('$target_file','$productname','$desc','$price','$category','$categoryID')";
            $results = mysqli_query($conn, $sqladd);
            if ($results) {
                echo '<script>alert("Product Added Successfully!");
                      window.location = \'index.php\';</script>';
            } else {
                echo '<script>alert("Failed to add product!");
                      window.location = \'index.php\';</script>';
            }
        } else {
            echo 'failed';
        }
    }
}


if(isset($_POST['editProducts'])){
    $productname = $conn->real_escape_string($_POST['productname']);
    $desc = $conn->real_escape_string($_POST['desc']);
    $price = $_POST['price'];
    $id = $_POST['itemid'];

    // Check if the new product name already exists
    $check_query = "SELECT COUNT(*) AS count FROM tbl_items WHERE item_Name = '$productname' AND item_ID != '$id'";
    $check_result = mysqli_query($conn, $check_query);
    $check_data = mysqli_fetch_assoc($check_result);
    $name_exists = $check_data['count'] > 0;

    if($name_exists) {
        echo '<script>alert("Product name already exists! Please choose a different name.");</script>';
    } else {
        $name = $_FILES['file']['name'];
        $fileExt = explode('.', $name);
        $fileActualExt = strtolower(end($fileExt));
        $target_dir = "../assets/img/items/";
        $target_file = $target_dir . $name;
        $extensions_arr = array("jpg","png","jpeg");

        if(in_array($fileActualExt,$extensions_arr)) {
            if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                $sqladd = "UPDATE tbl_items SET item_Image = '$target_file', item_Name = '$productname', item_Description='$desc', item_Price = '$price' WHERE item_ID = '$id'";
                $results = mysqli_query($conn, $sqladd);
                if($results){
                    echo '<script>alert("Product Updated Successfully!"); window.location = \'index.php\';</script>';
                } else {
                    echo '<script>alert("Failed to update product!"); window.location = \'index.php\';</script>';
                }
            } else {
                echo 'failed';
            }
        }
    }
}

/*Para sa DELETE*/ 
if(isset($_POST['deleteProducts'])){
    $itemid = $_POST['itemid'];
    $sqlDelete  = "DELETE FROM tbl_items WHERE item_ID = '$itemid'";
    $sqlres2 = mysqli_query($conn, $sqlDelete);
    if($sqlres2){
        echo "<script>alert('Successfully Deleted');</script>";
    }
    else {
        echo "<script>alert('Failed to Delete');</script>";
    }
}

if (isset($_SESSION['adminuserId'])) { ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>EMC Animal Clinic - Products</title>
<link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="keywords">
<meta content="" name="description">
<?php include '../includes/link.php'?>
<style>
.actionIcons {
    opacity: 1;
    cursor: pointer;
    margin-left: 1px;
    border:none;
    background-color:white;
}
</style>
</head>
<body>
<?php include '../spinner/spinner.php';?>
<?php require '../navbar.php'; ?>
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-light rounded h-100 p-4">
                <h3>List of Services</h3>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal"> Add Service <i class="fa-solid fa-circle-plus"></i></button><br><br> 
                <div class="table-responsive">
                    <table class="table" id="tblcategory">   
                        <thead>
                            <tr style="text-align:center;">
                                <th scope="col">Image</th>
                                <th scope="col">Service Name</th>
                                <th scope="col">Description</th>
                                <th scope="col">Price</th> 
                                <th scope="col">Action</th>       
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $sql1 = "SELECT * FROM tbl_items WHERE item_category = 'Services'";
                            $sqlres = mysqli_query($conn, $sql1);  
                            while($row = mysqli_fetch_assoc($sqlres)){
                                $image = $row['item_Image'];  
                                $product = $row['item_Name'];  
                                $description = $row['item_Description'];  
                                $price = $row['item_Price'];  
                                $id = $row['item_ID'];
                                $catID = $row['item_Category'];
                        ?>
                            <tr style="text-align:center;">
                                <td><img src = "<?php echo $image ?>" style = "width:60px;height:60px;" /></td>
                                <td><?php echo $product ?></td>
                                <td><?php echo $description ?></td>
                                <td><?php echo $price ?>.00</td>     
                                <td>
                                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editProduct<?php echo $id ?>"><i class="fa-solid fa-pen"></i> EDIT</button>
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteProduct<?php echo $id ?>"><i class="fa-solid fa-trash"></i> DELETE</button>
                                </td>          
                            </tr>
                        <?php }?>
                        </tbody>      
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Add Services Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Service</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Input Image</label>
                        <input type="file" name="file" accept="image/*" class="form-control" required >
                    </div>
                  
                    <div class="form-group">
                        <label for="exampleInputEmail1">Service Name</label>
                        <input type="text" name="productname" class="form-control"  placeholder="Service Name" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>
                        <textarea class="form-control"  rows="4" name="desc" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" ></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Price</label>
                        <input type="text" name="price" class="form-control"  placeholder="Price" onkeypress="if(event.keyCode<48 || event.keyCode>57)event.returnValue=false;" required>
                    </div>
                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="addProduct" class="btn btn-primary">ADD</button>
                    </form>
                </div>
        </div>
    </div>
</div>

<!-- Edit Services Modals -->
<?php
$sqlitems = "SELECT * FROM tbl_items";
$sqlres = mysqli_query($conn, $sqlitems);  
while($row = mysqli_fetch_assoc($sqlres)){
    $ids = $row['item_ID'];
    $image = $row['item_Image'];  
    $product = $row['item_Name'];  
    $description = $row['item_Description'];  
    $price = $row['item_Price'];  
    $catname = $row['item_Category'];
    $catID = $row['item_CategoryID'];
?>

<div class="modal fade" id="editProduct<?php echo $ids?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Service<?php echo $ids?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="index.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="itemid" value="<?php echo $ids ?>">
                    <div class="form-group">
                        <img src = "<?php echo $image ?>" style = "height:70px;width:70px;"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Input Image</label>
                        <input type="file" name="file" accept="image/*" class="form-control" required >
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputEmail1">Service Name</label>
                        <input type="text" name="productname" class="form-control" placeholder="Service Name" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;" required value = "<?php echo $product ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>
                        <textarea class="form-control"  rows="4" name="desc" onkeypress="if(event.keyCode<32 || event.keyCode>32 && event.keyCode<65 || event.keyCode>90 && event.keyCode<97 || event.keyCode>122)event.returnValue=false;"><?php echo $description?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Price</label>
                        <input type="text" name="price" class="form-control" placeholder="Price" onkeypress="if(event.keyCode<48 || event.keyCode>57)event.returnValue=false;" required value ="<?php echo $price ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="editProducts" class="btn btn-primary">SAVE</button>    
                </div>
            </form>
        </div>
    </div>
</div>
<?php } ?>

 <!-- Product Delete Modal-->
<?php
$sqlitems1 = "SELECT * FROM tbl_items";
$sqlres = mysqli_query($conn, $sqlitems1);  
while($row = mysqli_fetch_assoc($sqlres)){
    $ids = $row['item_ID'];
    $image = $row['item_Image'];  
    $product = $row['item_Name'];  
    $description = $row['item_Description'];  
    $price = $row['item_Price'];  
    $catname = $row['item_Category'];
    $catID = $row['item_CategoryID'];
?>
 <div class="modal fade" id="deleteProduct<?php echo $ids ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">      
                <center><i class="fa-solid fa-circle-exclamation" style ="color:red;font-size:100px;"></i><br><br>
                <p style="font-weight:bold; font-size:20px;">Are you sure you want to delete <?php echo $product ?>?</p></center>
                <div class="btnDelete" style = "display:flex;align-content:center;justify-content:center;gap:15px;">
                    <button type="submit" name="deleteProducts" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                <input type="hidden" name="itemid" value="<?php echo $ids ?>">
                </form>
            </div>  
        </div>
    </div>
</div>
<?php } ?>

<?php include '../includes/script.php'?>
</body>
</html>
<?php }
else {
   header("location: ../login.php");
}
?>