<?php 

 include ('../assets/database.php');
 session_start();
 if (isset($_SESSION['adminuserId'])) {
    $myId =  $_SESSION['adminuserId'];

 ?>
<?php
  $sqlprof = "SELECT * FROM adminuser WHERE ID = '$myId'";
  $sqlres = mysqli_query($conn,$sqlprof);
  $row = mysqli_fetch_assoc($sqlres);

    $user = $row['adminUsername'];
  $fname = $row['firstName'];
  $lname = $row['lastName'];
  $pass = $row['adminPassword'];

    if(isset($_POST['change'])){

        $lname = $_POST['lname'];
        $fname = $_POST['fname'];
        $pass = md5($_POST['password']);
        $pass2= md5($_POST['confirmpass']);

      if($pass2 == $pass){
        $sqlup = mysqli_query($conn, "UPDATE adminuser SET firstName = '$fname', lastName = '$lname', adminPassword='$pass2' WHERE ID = '$myId'");
        echo'<script> 
        alert("Profile Updated Successfully");
        window.location=document.referrer;</script>";';
      }
      else{
        echo'<script> 
        alert("Password does not match");
        window.location=document.referrer;</script>";';
      }
    }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EMC Animal Clinic - Profile</title>
    <link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
 
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">


    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />


    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">


    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>


<!-- DATATABLES ---->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
    
<style>
    .actionIcons {
    opacity: 1;
    cursor: pointer;
    margin-left: 1px;
    border:none;
    background-color:white;
}
    </style>
    
    <script>
jQuery(document).ready(function($) {
    $('#tblcategory').DataTable({     
    }
    );
} );

</script>

</head>

<body>

        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <?php require '../navbar.php';
          
        ?>

    <!-- Table Start -->
    <?php
   
    

?>

    <div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4"></h6>
                <div class="container-xl px-4 mt-4">
                    <div class="row">
                        <div class="col-xl-4">
                            <!-- Profile picture card-->
                            <div class="card mb-4 mb-xl-0">
                                <div class="card-header">Profile Picture</div>
                                <div class="card-body text-center">
                                   
                                    <img class="img-account-profile rounded-circle mb-2" src="../../admin/assets/img/profile.png" style="width: 100%; height: 50%;"alt="">
                            
                                    <div class="small font-italic text-muted mb-4">DEFAULT PROFILE ADMIN</div>
                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8">
                            <!-- Account details card-->
                            <div class="card mb-4">
                                <div class="card-header">Account Details</div>
                                <div class="card-body">
                                    <form method="POST">
                                  
                                        <div class="mb-3">
                                            <label class="small mb-1" for="inputUsername">Username</label>
                                            <input class="form-control" id="inputUsername" name="username" type="text" placeholder="Enter your username" value="<?php echo $user?>" readonly>
                                        </div>
                                        <!-- Form Row-->
                                        <div class="row gx-3 mb-5">
                                      
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputFirstName">First name</label>
                                                <input class="form-control" id="inputFirstName" name="fname" type="text" placeholder="Enter your first name" value="<?php echo $fname?>">
                                            </div>
                                         
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Last name</label>
                                                <input class="form-control" id="inputLastName" name="lname" type="text" placeholder="Enter your last name" value="<?php echo $lname?>">
                                            </div>
                                      
                                            
                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Password</label>
                                                <input class="form-control" id="inputLastName" name="password" type="password" placeholder="Enter your last name" value="<?php echo $pass?>">
                                            </div>

                                            <div class="col-md-6">
                                                <label class="small mb-1" for="inputLastName">Confirm Password</label>
                                                <input class="form-control" id="inputLastName"  name="confirmpass" type="password" placeholder="Confirm Password" value="<?php echo $pass?>">
                                            </div>
                                            
                                            
                                        </div>
                                        <br><br>
                                        <button class="btn btn-primary" type="submit" name="change" >Save changes</button>
                                        </div>
                                
                                      
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Table End -->

<br><br>

        </div>
        <!-- Content End -->


        <!-- Back to Top -->
      
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>
<?php

}
else {
   header("location: ../login.php");
}
?>