<?php 
include ('../assets/database.php');
session_start();
if (isset($_SESSION['adminuserId'])) {
    
$sqlproducts = mysqli_query($conn,"SELECT * FROM tbl_items WHERE item_category = 'Products'");
$totalproducts = mysqli_num_rows($sqlproducts); 

$sqlservices = mysqli_query($conn,"SELECT * FROM tbl_items WHERE item_category = 'Services'");
$totalservices = mysqli_num_rows($sqlservices);

$sqlpending = mysqli_query($conn,"SELECT * FROM tbl_order WHERE order_Status = 'PENDING'");
$totalpending = mysqli_num_rows($sqlpending);

$sqlFinish = mysqli_query($conn,"SELECT * FROM tbl_order WHERE order_Status = 'FINISH'");
$totalfinish = mysqli_num_rows($sqlFinish);

$sqlCancel = mysqli_query($conn,"SELECT * FROM tbl_order WHERE order_Status = 'CANCEL'");
$totalcancel = mysqli_num_rows($sqlCancel);

$sqltra = mysqli_query($conn,"SELECT * FROM tbl_order WHERE order_finish = '1' ");
$totaltransactions = mysqli_num_rows($sqltra); 

$sqlUsers = mysqli_query($conn,"SELECT * FROM tbl_users");
$totalUsers = mysqli_num_rows($sqlUsers); 

$sqlPost = mysqli_query($conn,"SELECT * FROM tbl_post");
$totalPost = mysqli_num_rows($sqlPost); 

$sql11 = "SELECT SUM(order_total) as totalsales FROM tbl_order WHERE order_finish = '1'";
    $sqlres1 = mysqli_query($conn, $sql11);
    $row1 = mysqli_fetch_array($sqlres1);
    $totalsales = $row1['totalsales'];

$date = date('Y/m/d');
$sql1 = "SELECT SUM(order_total) as todaysales FROM tbl_order WHERE order_finish = '1' and DATE(order_finishDate) = '$date' ";
$sqlres = mysqli_query($conn, $sql1);
    $row = mysqli_fetch_array($sqlres);
    $todaysales = $row['todaysales'];
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>EMC Animal Clinic - Admin</title>
    <link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php include '../includes/link.php'?>
</head>
<body>
<?php include '../spinner/spinner.php';?>
<?php require '../navbar.php'; ?>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4 ">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <a href = "../users/index.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-users fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Users </p>
                        <h6 class="mb-0"><?php echo $totalUsers ?></h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-xl-3">
            <a href = "../sales/">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa-solid fa-peso-sign fa-3x text-primary "></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Sales</p>
                        <?php if( $totalsales  == false) {  $totalsales  = "0";}?>
                        <h6 class="mb-0">₱ <?php echo number_format( $totalsales ) ?></h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-xl-3">
            <a href = "../orders/finishorders.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2"> Total Transactions</p>
                        <h6 class="mb-0"><?php echo $totaltransactions ?></h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-xl-3">
            <a href = "../products/index.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-list fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Products</p>
                        <h6 class="mb-0"><?php echo $totalproducts ?></h6>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
<div class="container-fluid pt-4 px-4 ">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <a href = "../services/index.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-list fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Services</p>
                        <h6 class="mb-0"><?php echo $totalservices ?></h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-xl-3">
            <a href = "../orders/index.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-receipt fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Pending Orders</p>
                        <h6 class="mb-0"><?php echo $totalpending ?></h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-xl-3">
            <a href = "../orders/finishorders.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-receipt fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Finish Orders</p>
                        <h6 class="mb-0"><?php echo  $totalfinish ?></h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-xl-3">
            <a href = "../orders/cancelorders.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-receipt fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Cancel Orders</p>
                        <h6 class="mb-0"><?php echo  $totalcancel ?></h6>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
<div class="container-fluid pt-4 px-4 ">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <a href = "../post/index.php">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-image fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Posts </p>
                        <h6 class="mb-0"><?php echo $totalPost ?></h6>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
<!-- Content End -->
<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
<?php include '../includes/script.php'?>
</body>
</html>
<?php }
else {
   header("location: ../login.php");
}
?>