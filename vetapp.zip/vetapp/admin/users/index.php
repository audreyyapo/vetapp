<?php 
 include ('../assets/database.php');
 session_start();


/*Para sa DELETE*/ 
if(isset($_POST['deleteUsers'])){
    $userid = $_POST['userID'];
    $sqlDelete  = "DELETE FROM tbl_users WHERE user_ID = '$userid'";
    $sqlres2 = mysqli_query($conn, $sqlDelete);
    if($sqlres2){
        echo "<script>
        alert('User Successfully Deleted');
        </script>";
    } else {
        echo "<script>
        alert('User Failed to Delete');

        </script>";
    }
}


 if (isset($_SESSION['adminuserId'])) {
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>EMC Animal Clinic - Users</title>
<link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="keywords">
<meta content="" name="description">
<?php include '../includes/link.php'?> 
</head>
<body>
<?php include '../spinner/spinner.php';?>
<?php require '../navbar.php'; ?>
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-light rounded h-100 p-4">
                <h3>List of Users</h3>
                <div class="table-responsive">
                    <table class="table" id="tblcategory">   
                        <thead>
                            <tr style="text-align:center;">
                                <th scope="col">Username</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Contact No.</th>
                                <th scope="col">Address</th>
                                <th scope ="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $sql1 = "SELECT * FROM tbl_users";
                            $sqlres = mysqli_query($conn, $sql1);  
                            while($row = mysqli_fetch_assoc($sqlres)){
                                $username = $row['userName'];  
                                $firstname = $row['firstName'];  
                                $lastname = $row['lastName'];  
                                $email = $row['email'];  
                                $contact = $row['contactNumber'];
                                $address = $row['user_Address'];
                                $id = $row['user_ID']; 
                                $fullname = $firstname.' '.$lastname;
                        ?>
                            <tr style="text-align:center;">
                                <td><?php echo $username ?></td>
                                <td><?php echo $fullname ?></td>
                                <td><?php echo $email ?></td>
                                <td><?php echo $contact ?></td>
                                <td><?php echo $address ?></td> 
                                <td>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteUser<?php echo $id ?>"><i class="fa-solid fa-trash"></i> DELETE</button>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                                   
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    $sql1 = "SELECT * FROM tbl_users";
    $sqlres = mysqli_query($conn, $sql1);  
    while($row = mysqli_fetch_assoc($sqlres)){
        $id = $row['user_ID']; 
?>
<div class="modal fade" id="deleteUser<?php echo $id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">      
                <center><i class="fa-solid fa-circle-exclamation" style ="color:red;font-size:100px;"></i><br><br>
                <p style="font-weight:bold; font-size:20px;">Are you sure you want to delete this user?<?php echo $id ?></p></center>
                <div class="btnDelete" style = "display:flex;align-content:center;justify-content:center;gap:15px;">
                    <button type="submit" name="deleteUsers" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                <input type="hidden" name="userID" value="<?php echo $id ?>">
                </form>
            </div>  
        </div>
    </div>
</div>
<?php } ?>


<?php include '../includes/script.php'?>
</body>
</html>
<?php }
else {
   header("location: ../login.php");
}
?>