<?php 
include ('assets/database.php');
     

$sqlnotif = mysqli_query($conn, "SELECT * FROM `tbl_notif` ORDER BY notif_ID DESC LIMIT 5 ");
while($sqlnt = mysqli_fetch_array($sqlnotif)){
    $notifcart = $sqlnt['notif_cartID'];
    $datetime = $sqlnt['notif_dateTime'];
    $purpose = $sqlnt['notif_Purpose'];

    $sqlno = mysqli_query($conn, "SELECT * FROM `tbl_order` WHERE order_ID = '$notifcart'");
    $sqlntt = mysqli_fetch_array($sqlno);
    $userid = $sqlntt['user_ID'];
    $status = $sqlntt['order_Status'];

    $sqlusers = mysqli_query($conn, "SELECT * FROM tbl_users WHERE user_ID = '$userid '");
    $rowuser = mysqli_fetch_array($sqlusers);

    $fullname = $rowuser['firstName'].''.$rowuser['lastName'];;
?>
<a id = "notif" href="#" class="dropdown-item" style = "padding:0;">
<?php 
    if($status == 'PENDING' && $purpose == 'CANCEL') {
    ?>
    <a id ="main-a" href="../orders/cancelorder.php">
    <p id = "new-order"class="fw-normal" >CANCEL ORDER
    <?php } else { ?>
    <a id ="main-a" href="../orders/index.php?=<?php echo $notifcart ?>">
    <p id = "new-order"class="fw-normal" >NEW ORDER
<?php } ?>


<br><?php echo $datetime ?></p></a>

</a>
<?php
 } ?>

 <style>
    #new-order{
        color:black;
        text-align:center;
        padding:0 5px;
        margin-bottom:2px;
        font-size:15px;
    }
    #new-order:hover{
        color:black;
        background:#bababa;
    }
</style>
