<?php   
include ('assets/database.php');
     ?>

                          <?php    $sqlpending = mysqli_query($conn,"SELECT * FROM tbl_notif WHERE notif_Status='0'");
                                   $totalpending = mysqli_num_rows($sqlpending); 
                                    if($totalpending == 0){
                                        $hidden = "hidden";
                                    }
                                   
                                   ?>

                            <p id = "counts" class = "counts text-white" <?php echo $hidden?>><?php echo  $totalpending ?> </p>
