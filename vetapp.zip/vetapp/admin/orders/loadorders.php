<?php 
 include ('../assets/database.php');

 $Count = "SELECT COUNT(*) AS count FROM tbl_order WHERE order_finish = 0 AND order_Status != 'CANCEL'";
 $sqlres1 = mysqli_query($conn, $Count);
 $rows = mysqli_fetch_assoc($sqlres1);
 $count = $rows['count'];
 ?>
<table class="table" id="tblcategory">
    <thead>
    <tr>
        <th scope="col">Name</th>
        <th scope="col">Email</th>                                        
        <th scope="col">Amount</th>
        <th scope="col">Method</th>
        <th scope="col">Date</th>
        <th scope="col">Items</th>
        <th scope="col">Ref No.</th>
        <th scope="col">Order Status</th>
    </tr>
    </thead>
    <tbody>
    <?php
   
 
    $sql1 = "SELECT * FROM tbl_order WHERE order_finish = 0 AND order_Status != 'CANCEL' ORDER BY order_ID DESC " ;
    $sqlres = mysqli_query($conn, $sql1);  
    while($row = mysqli_fetch_assoc($sqlres)){
        $ID = $row['order_ID'];
        $userID = $row['user_ID'];
        $addresscust = $row['order_Address'];
        $total = $row['order_total'];
        $method = $row['order_mode'];
        $refNo = $row['order_refNo'];
        $orderstatus = $row['order_Status'];
        $date = $row['order_startDate'];

        //getting user info
        $sqluser = "SELECT * FROM tbl_users WHERE user_ID ='$userID'";
        $sqlress = mysqli_query($conn, $sqluser);  
        $rowuser = mysqli_fetch_assoc($sqlress);

        $username = $rowuser['userName'];
        $fullname = $rowuser['firstName'].' '.$rowuser['lastName'] ;
        $email = $rowuser['email'];
    ?>
                                 
    <tr>
        <td><?php echo $fullname ?></td>
        <td><?php echo $email ?></td>                      
        <td>₱ <?php echo $total ?>.00</td>
        <td><?php echo $method ?></td>
        <td><?php echo $date ?></td>
        <td>
            <button type = "button" class = "btn btn-primary" data-bs-toggle="modal" data-bs-target="#itemsModal<?php echo $ID?>">View</buttons>
        </td>
        <td><?php echo $refNo ?></td>
        <td>
            <form method="POST"action="functions.php">
                <?php if($orderstatus == "PENDING") { ?>
                    <button type = "submit" name = "confirm" class = "btn btn-primary">CONFIRM</button>
                    <button type = "submit" name = "cancel" class = "btn btn-danger">CANCEL</button>
                <?php } 
                else if($orderstatus == "CONFIRM"){ ?>
                    <button type = "submit" name = "finish" class = "btn btn-success">FINISH</button>
                <?php } 
                else if($orderstatus == "FINISH"){ ?>       
                    <p>Order Delivered</p>
                <?php } ?>
                <input type="hidden" value="<?php echo $ID ?>" name="updateID">
                <input type = "hidden" value = "<?php echo $userID ?>" name = "users">
                <input type="hidden" value="<?php echo $orderstatus ?>" name="orderstatus">
            </form>
        </td>
        
    </tr>
    <?php } ?>
    </tbody>
</table>
<?php if($count==0){?>
    <div style = "text-align:center;font-weight:bold;color:#313131;">No orders yet!</div>
<?php } ?>
<style>
#tblcategory{
    width:100%;
    font-size:16px;
    background:white;
}
#tblcategory td{
    text-align:center;     
}
#tblcategory th{
    text-align:center;
}
button{
    cursor:pointer;
}
</style>