<?php 
session_start();
include ('../assets/database.php');

if($_SERVER["REQUEST_METHOD"] == "POST") {


    if(isset($_POST['confirm'])) {

        $user = $_POST['users'];
        $updateID = $_POST['updateID'];

        $updateOrder = "UPDATE `tbl_order` SET order_Status = 'CONFIRM' WHERE `order_ID`='$updateID'";   
        $result = mysqli_query($conn, $updateOrder);
        if($result){

            $insert_data = "INSERT INTO tbl_usernotif (`user_ID`, `order_ID`, `notif_orderStatus`) VALUES ('$user', '$updateID', 'ORDER CONFIRMED')";
            $query = mysqli_query($conn, $insert_data);
            echo "<script>alert('Order Confirmed!');
                window.location=document.referrer;</script>";
        }
        else{
            echo "<script>alert('Order Failed to Confirm!');
            window.location=document.referrer;</script>";
        }
    }

    if(isset($_POST['finish'])) {

        $user = $_POST['users'];
        $updateID = $_POST['updateID'];

        $updateOrder = "UPDATE `tbl_order` SET order_Status = 'FINISH',order_finishDate = '$currentdate', order_finish = 1 WHERE `order_ID`='$updateID'";   
        $result = mysqli_query($conn, $updateOrder);
        if($result){

            $sqlorderhistory = "UPDATE tbl_users SET user_orderHistory = '1' WHERE user_ID = '$user'";
            $sqlres1 = mysqli_query($conn,$sqlorderhistory);

            $insert_data = "INSERT INTO tbl_usernotif (`user_ID`, `order_ID`, `notif_orderStatus`) VALUES ('$user', '$updateID', 'ORDER DELIVERED')";
            $query = mysqli_query($conn, $insert_data);

            echo "<script>alert('Order Finish!');
                window.location=document.referrer;</script>";
        }
        else{
            echo "<script>alert('Order Failed to Finish!');
            window.location=document.referrer;</script>";
        }
    }

    if(isset($_POST['cancel'])) {

        $user = $_POST['users'];
        $updateID = $_POST['updateID'];

        $updateOrder = "UPDATE `tbl_order` SET order_Status = 'CANCEL' WHERE `order_ID`='$updateID'";   
        $result = mysqli_query($conn, $updateOrder);
        if($result){
            echo "<script>alert('Order Cancel!');
                window.location=document.referrer;</script>";
        }
        else{
            echo "<script>alert('Order Failed to Cancel!');
            window.location=document.referrer;</script>";
        }
    }



}

?>