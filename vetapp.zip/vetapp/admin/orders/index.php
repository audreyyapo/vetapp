<?php 
 include ('../assets/database.php');
 session_start();
 if (isset($_SESSION['adminuserId'])) {
 ?>
 <?php
    $sqlupdate = mysqli_query($conn, "UPDATE tbl_notif SET notif_Status ='1'");
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EMC Animal Clinic - Orders</title>
    <link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    
    <?php include '../includes/link.php'?>
    <link href="../../admin/assets/css/style.css" rel="stylesheet">
</head>
<body>
<?php 
    include '../spinner/spinner.php';
    require '../navbar.php';
    require 'statusmodal.php';
?>
<div class="tab">
<button id = "for-current" style = "border:1px solid #009cff;background:#009cff;color:#fff;font-weight:bold" class="tablinks" onclick="window.location.href='index.php';">Current Orders</button>
<button id = "for-finish" class="tablinks" onclick="window.location.href='finishorders.php';">Finish Orders</button>
<button id = "for-cancel" class="tablinks" onclick="window.location.href='cancelorders.php';">Cancel Orders</button>
</div>
<div id="CURRENT">
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Current Orders</h6>                    
                            <div class="table-responsive">
                            <div id="loadcurrent"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->

<br><br>
<script>
     
     $(document).ready(function()
     {
        setInterval(function(){
            $("#loadcurrent").load("loadorders.php");
        },300);
        });
     
        </script>
        
</div>
<?php include '../includes/script.php'?>
</body>

</html>
<?php

}
else {
   header("location: ../index.php");
}
?>

<style>
    #tblcategory{
        width:100%;
        font-size:16px;
    }
    #tblcategory td{
        text-align:center;
        
    }
    #tblcategory th{
        text-align:center;
        
    }
    button{
        cursor:pointer;
    }
    .actionIcons {
    opacity: 1;
    cursor: pointer;
    margin-left: 1px;
    border:none;
    background-color:white;
}
body {font-family: Arial;}

/* Style the tab */
.tab {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: whitesmoke;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  outline:none;
  border-top: none;
}

    </style>