 <?php 
  $sql1 = "SELECT * FROM tbl_order WHERE order_finish = 1 AND order_Status = 'FINISH'" ;
  $sqlres = mysqli_query($conn, $sql1);  
  while($row = mysqli_fetch_assoc($sqlres)){
    $orderid = $row['order_ID'];
    $userId = $row['user_ID'];
        ?>
          <!-- Modal -->
            <div class="modal fade" id="finishModal<?php echo $orderid ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Item Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">
                <div id = "items-flex" class="form-group">
                        <div class = "for-image">
                            <p></p>
                        </div>
                        <div class = "for-name">
                            <p>Item Name</p>
                        </div>
                        <div class = "for-quantity">
                            <p>Quantity</p>
                        </div>
                </div>
                <?php
                    $mysql = "SELECT * FROM `tbl_orderitems` WHERE order_itemsID = '$orderid' ";
                    $myresult = mysqli_query($conn, $mysql);
                    while($myrow = mysqli_fetch_assoc($myresult)){
                                       
                        $idOrder = $myrow['order_ID'];
                        $currentOrdersID = $myrow['order_itemsID'];
                        $cartID = $myrow['order_cartID'];
                                   
                                  
                        $sqlcart = "SELECT * FROM tbl_cart WHERE cart_ID = '$cartID' and cart_userID ='$userId'";
                        $sqlress  = mysqli_query($conn, $sqlcart);
                        $rowcart =  mysqli_fetch_array($sqlress);
                        $cart_item = $rowcart['cart_itemID'];
                        $cartUserID = $rowcart['cart_userID']; 
                        $quantity =  $rowcart['cart_Quantity'];
                        $date = $rowcart['cart_Date'];

                        $sqlmenu = "SELECT * FROM tbl_items WHERE item_ID = '$cart_item'";
                        $sqlrr  = mysqli_query($conn, $sqlmenu);
                        $menurow =  mysqli_fetch_array($sqlrr);
                        $menuName = $menurow['item_Name'];   
                        $pic = $menurow['item_Image']; 
                    ?>
                    <div id = "items-flex" class="form-group">
                        <div class = "for-image">
                            <img src = "<?php echo $pic ?>">
                        </div>
                        <div class = "for-name">
                            <p><?php echo $menuName ?></p>
                        </div>
                        <div class = "for-quantity">
                            <p><?php echo $quantity?></p>
                        </div>
                       
                       
                       
                    </div>
                 
                    <?php } ?>
                </form>
               
                </div>
            </div>
            </div>
            </div>
            <?php } ?>

            <style>
 #items-flex{
    display:flex;
    width:100%;
    padding:0 15px;
    margin-bottom:15px;
}
.for-image{
    width:15%;
    margin-top:-15px;
    text-align:left;
}
.for-image img{
    object-fit:contain;
    width:80px;
    height:50px;
}
.for-name{
    width:50%;
    text-align:center;
}
.for-quantity{
    width:15%;
    text-align:center;
}
.for-size{
    width:20%;
    text-align:center;
}
.for-addons{
    width:20%;
    text-align:center;
}
.header{
    font-weight:bold;
}
</style>