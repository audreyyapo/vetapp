<?php 
 include ('../assets/database.php');
 session_start();
 if (isset($_SESSION['adminuserId'])) {
 ?>
 <?php
    $sqlupdate = mysqli_query($conn, "UPDATE tbl_notif SET notif_Status ='1'");
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EMC Animal Clinic - Orders</title>
    <link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    
    <?php include '../includes/link.php'?>
    <link href="../../admin/assets/css/style.css" rel="stylesheet">
</head>
<body>
<?php 
    include '../spinner/spinner.php';
    require '../navbar.php';
    require 'finishmodal.php';
?>
<div class="tab">
<button id = "for-current" class="tablinks" onclick="window.location.href='index.php';">Current Orders</button>
<button id = "for-finish" style = "border:1px solid #009cff;background:#009cff;color:#fff;font-weight:bold" class="tablinks" onclick="window.location.href='finishorders.php';">Finish Orders</button>
<button id = "for-cancel" class="tablinks" onclick="window.location.href='cancelorders.php';">Cancel Orders</button>
</div>
<div id="FINISH">
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Finish Orders</h6>                    
                            <div class="table-responsive">
                            <?php 
 include ('../assets/database.php');

 $Count = "SELECT COUNT(*) AS count FROM tbl_order WHERE order_finish = 1 AND order_Status = 'FINISH'";
 $sqlres1 = mysqli_query($conn, $Count);
 $rows = mysqli_fetch_assoc($sqlres1);
 $count = $rows['count'];
 ?>
<table class="table" id="tblcategory">
    <thead>
    <tr>
        <th scope="col">Name</th>
        <th scope="col">Email</th>                                        
        <th scope="col">Amount</th>
        <th scope="col">Method</th>
        <th scope="col">Date</th>
        <th scope="col">Items</th>
        <th scope="col">Ref No.</th>
    </tr>
    </thead>
    <tbody>
    <?php
   
 
    $sql1 = "SELECT * FROM tbl_order WHERE order_finish = 1 AND order_Status = 'FINISH' ORDER BY order_ID DESC " ;
    $sqlres = mysqli_query($conn, $sql1);  
    while($row = mysqli_fetch_assoc($sqlres)){
        $ID = $row['order_ID'];
        $userID = $row['user_ID'];
        $addresscust = $row['order_Address'];
        $total = $row['order_total'];
        $method = $row['order_mode'];
        $refNo = $row['order_refNo'];
        $orderstatus = $row['order_Status'];
        $date = $row['order_startDate'];

        //getting user info
        $sqluser = "SELECT * FROM tbl_users WHERE user_ID ='$userID'";
        $sqlress = mysqli_query($conn, $sqluser);  
        $rowuser = mysqli_fetch_assoc($sqlress);

        $username = $rowuser['userName'];
        $fullname = $rowuser['firstName'].' '.$rowuser['lastName'] ;
        $email = $rowuser['email'];
    ?>
                                 
    <tr>
        <td><?php echo $fullname ?></td>
        <td><?php echo $email ?></td>                      
        <td>₱ <?php echo $total ?>.00</td>
        <td><?php echo $method ?></td>
        <td><?php echo $date ?></td>
        <td>
            <button type = "button" class = "btn btn-primary" data-bs-toggle="modal" data-bs-target="#finishModal<?php echo $ID?>">View</buttons>
        </td>
        <td><?php echo $refNo ?></td>
       
        
    </tr>
    <?php } ?>
    </tbody>
</table>
<?php if($count==0){?>
    <div style = "text-align:center;font-weight:bold;color:#313131;">No Finish Orders Yet!</div>
<?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->

<br><br>
<script>
     
     $(document).ready(function()
     {
        setInterval(function(){
            $("#loadcurrent").load("loadfinish.php");
        },300);
        });
     
        </script>
        
</div>

<?php include '../includes/script.php'?>
    <script src="../../admin/assets/js/main.js"></script>
</body>

</html>
<?php

}
else {
   header("location: ../index.php");
}
?>

<style>
    #tblcategory{
        width:100%;
        font-size:16px;
    }
    #tblcategory td{
        text-align:center;
        
    }
    #tblcategory th{
        text-align:center;
        
    }
    button{
        cursor:pointer;
    }
    .actionIcons {
    opacity: 1;
    cursor: pointer;
    margin-left: 1px;
    border:none;
    background-color:white;
}
body {font-family: Arial;}

/* Style the tab */
.tab {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: whitesmoke;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  outline:none;
  border-top: none;
}

    </style>