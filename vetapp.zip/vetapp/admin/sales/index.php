<?php 
 include ('../assets/database.php');
 session_start();
 if (isset($_SESSION['adminuserId'])) {
 ?>
 <?php
    $sqlupdate = mysqli_query($conn, "UPDATE tbl_notif SET notif_Status ='1'");
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EMC Animal Clinic - Sales</title>
    <link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php include '../includes/link.php'?>
    <link href="../../admin/assets/css/style.css" rel="stylesheet">
</head>
<body>
<body>
<?php
    require '../navbar.php';
?>
<div id="SALES">
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-light rounded h-100 p-4">
            <h3>Total Sales</h3>
                <div class="table-responsive">
                    <table class="table" id="tblcategory"> 
                        <thead>
                            <tr>
                                <th scope="col">Fullname</th>
                                <th scope="col">Email</th>                                                
                                <th scope="col">Amount</th>
                                <th scope="col">Method</th>
                                <th scope="col">Date</th>
                                <th scope="col">Time</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $sql1 = "SELECT * FROM tbl_order WHERE order_finish = 1";
                        $sqlres = mysqli_query($conn, $sql1);  
                        while($row = mysqli_fetch_assoc($sqlres)){
                            $ID = $row['order_ID'];
                            $userID = $row['user_ID'];
                            $amount = $row['order_total'];
                            $method = $row['order_mode'];
                            $refNo = $row['order_refNo'];
                            date_default_timezone_set('Asia/Manila');
                            $newdate = date('m/d/Y', strtotime($date));
                            $time = date('h:i a', strtotime($date));

                            //getting user info
                            $sqluser = "SELECT * FROM tbl_users WHERE user_ID ='$userID'";
                            $sqlress = mysqli_query($conn, $sqluser);  
                            $rowuser = mysqli_fetch_assoc($sqlress);

                            $username = $rowuser['userName'];
                            $fullname = $rowuser['firstName'].' '.$rowuser['lastName'] ;
                            $email = $rowuser['email'];
                        ?>
                        <tr>
                            <td><?php echo $fullname ?></td>
                            <td><?php echo $email ?></td>                         
                            <td>₱ <?php echo $amount ?>.00</td>
                            <td><?php echo $method ?></td> 
                            <td><?php echo $newdate ?></td>
                            <td><?php echo $time ?></td>
                        </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>
</div>
<?php include '../includes/script.php'?>
</body>

</html>
<?php

}
else {
   header("location: ../index.php");
}
?>

<style>
    #tblcategory{
        width:100%;
        font-size:16px;
    }
    #tblcategory td{
        text-align:center;
        
    }
    #tblcategory th{
        text-align:center;
        
    }
    button{
        cursor:pointer;
    }
    .actionIcons {
    opacity: 1;
    cursor: pointer;
    margin-left: 1px;
    border:none;
    background-color:white;
}
body {font-family: Arial;}

/* Style the tab */
.tab {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: whitesmoke;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  outline:none;
  border-top: none;
}

    </style>