<?php 
include ('assets/database.php');
session_start();
$myId =  $_SESSION['adminuserId'];
$sql1 = "SELECT * FROM adminuser WHERE ID = $myId";
$sql2 = mysqli_query($conn, $sql1);
while($row = mysqli_fetch_assoc($sql2)){
    $uname = $row['adminUsername'];
    $lname = $row['lastName'];
    $fname = $row['firstName'];
}
$profilename = $fname.' '.$lname;
$image = "../../admin/assets/img/profile.png";
?>
<html>
<head>
<title>VET App</title>
<link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>

<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-light navbar-light">
        <a href="../dashboard" class="navbar-brand mx-5 mb-3 fw-bold">
            <img  src="../../admin/assets/img/vetapp-logo.jpeg" alt="Logo" style="width:60px; height: 60px;border-radius:5px;"> &nbsp; &nbsp;VET APP
        </a>
        <div class="d-flex align-items-center ms-4 mb-4">
            <div class="position-relative">
                <img class="rounded-circle" src="<?php echo $image ?>" alt="" style="width: 40px; height: 40px;">
                <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
            </div>
            <div class="ms-3">
                <span>Admin</span>
            </div>
        </div>
        <div class="navbar-nav w-100">
            <a href="../dashboard" class="nav-item nav-link"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
            <a href="../products" class="nav-item nav-link"><i class="fa fa-list me-2"></i>Products</a>
            <a href="../services" class="nav-item nav-link"><i class="fa fa-list me-2"></i>Services</a>
            <a href="../orders" class="nav-item nav-link"><i class="fa fa-laptop me-2"></i>Orders</a>
            <!--<div class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Transactions</a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="../orders/index.php" class="dropdown-item">Point of Sales</a>
                    <a href="../orders" class="dropdown-item">ORDERS</a>               
                </div>
            </div>-->
            <a href="../post" class="nav-item nav-link"><i class="fa fa-image me-2"></i>Newsfeed</a> 
            <a href="../sales" class="nav-item nav-link"><i class="fa fa-peso-sign me-2"></i>Sales</a> 
            <a href="../users" class="nav-item nav-link"><i class="fa fa-users me-2"></i>Users</a>
        </div>
    </nav>
</div>
<!-- Sidebar End -->
<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
        <?php
            date_default_timezone_set('Asia/Manila');
            $date = date('m/d/Y h:i a', time());
        ?>
        <span  style="color:black">Welcome to Admin Portal!</span>
        </form>
        <div class="navbar-nav align-items-center ms-auto">
        <script>
            $(document).ready(function(){
                setInterval(function(){
                    $("#loadnotif").load("../loadnotif.php");
                },300);
            });

            $(document).ready(function(){
                setInterval(function(){
                    $("#loadnotifnum").load("../notifnum.php");
                },300);
            });
        </script>
        
        <div class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                <div id="loadnotifnum"></div><i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Order Notification</span>
            </a>
            <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0" style = "padding:5px;">
                <div id="loadnotif"></div>
                    <hr class="dropdown-divider">
                    <a href="../orders" class="dropdown-item text-center">See all notifications</a>
            </div>
            </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <img class="rounded-circle me-lg-2" src="<?php echo $image ?>" alt="" style="width: 40px; height: 40px;">
                        <span class="d-none d-lg-inline-flex"><?php echo $profilename ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                        <a href="../profile" class="dropdown-item">My Profile</a>
                        <a href="../assets/_logout.php" class="dropdown-item">Log Out</a>
                    </div>
                </div>
        </div>
        <script>
            function counts(){
                document.getElementById("counts").value;
            }
            setInterval(counts, 1000);
        </script>
    </nav>
    <!-- Navbar End -->
</html>
<style>
.counts{
    background:red;
    border-radius:50%;
    font-size:10.5px;
    width:16px;
    text-align:center;
    position:absolute;
    top:8px;
    left:50px;
}
@media(max-width:600px){
    .counts{
        left:41px;
    }
}
</style>