<?php 
 include ('../assets/database.php');
 session_start();


/*Para sa DELETE*/ 
if(isset($_POST['deletePost'])){
    $postid = $_POST['postID'];
    $sqlDelete  = "DELETE FROM tbl_post WHERE post_ID = '$postid'";
    $sqlres2 = mysqli_query($conn, $sqlDelete);
    if($sqlres2){
        echo "<script>
        alert('Post Successfully Deleted');
        </script>";
    } else {
        echo "<script>
        alert('Post Failed to Delete');

        </script>";
    }
}

/*Para sa INACTIVE*/ 
if(isset($_POST['deactivePost'])){
    $postid = $_POST['postID'];
    $sqlupdate = "UPDATE tbl_post SET post_Status = 'INACTIVE' WHERE post_ID = '$postid'";
    $sqlres2 = mysqli_query($conn, $sqlupdate);
    if($sqlres2){
        echo "<script>
        alert('Post Successfully Inactive');
        </script>";
    } else {
        echo "<script>
        alert('Post Failed to Inactive');

        </script>";
    }
}

/*Para sa ACTIVATE*/ 
if(isset($_POST['activatePost'])){
    $postid = $_POST['postID'];
    $sqlupdate = "UPDATE tbl_post SET post_Status = 'ACTIVE' WHERE post_ID = '$postid'";
    $sqlres2 = mysqli_query($conn, $sqlupdate);
    if($sqlres2){
        echo "<script>
        alert('Post Successfully Activated');
        </script>";
    } else {
        echo "<script>
        alert('Post Failed to Activate');

        </script>";
    }
}

 if (isset($_SESSION['adminuserId'])) {
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>EMC Animal Clinic - Users</title>
<link rel = "icon" href ="../assets/img/vetapp-logo.jpeg" type = "image/x-icon">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="keywords">
<meta content="" name="description">
<?php include '../includes/link.php'?> 
</head>
<body>
<?php include '../spinner/spinner.php';?>
<?php require '../navbar.php'; ?>
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-light rounded h-100 p-4">
                <h3>Users Newsfeed</h3>
                <div class="table-responsive">
                    <table class="table" id="tblcategory">   
                        <thead>
                            <tr style="text-align:center;">
                                <th scope="col">Image</th>
                                <th scope="col" style = "width:30%;">Description</th>
                                <th scope = "col">User</th>
                                <th scope="col">Date</th>
                                <th scope="col">Status</th>
                                <th scope ="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $sql1 = "SELECT * FROM tbl_post";
                            $sqlres = mysqli_query($conn, $sql1);  
                            while($row = mysqli_fetch_assoc($sqlres)){
                                $image = $row['post_Image'];  
                                $description = $row['post_Description'];  
                                $date = $row['post_Date'];  
                                $status = $row['post_Status'];
                                $user = $row['user_ID'];
                                $id = $row['post_ID'];
                                
                                
                                $sqlname = "SELECT * FROM tbl_users WHERE user_ID = '$user'";
                                $sqlresult = mysqli_query($conn, $sqlname);
                                $rows = mysqli_fetch_assoc($sqlresult);

                                $fname = $rows['firstName'];
                                $lname = $rows['lastName'];
                                $fullname = $fname .' '. $lname;


                        ?>
                            <tr style="text-align:center;">
                                <td><img src = "../shop/<?php echo $image ?>" style = "height:60px;width:75px;"/></td>
                                <td style = "width:30%;"><?php echo $description ?></td>
                                <td><?php echo $fullname ?></td>
                                <td><?php echo $date ?></td>
                                <td><?php echo $status ?></td>
                                <td>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deletePost<?php echo $id ?>"><i class="fa-solid fa-trash"></i> DELETE</button>
                                <?php if ($status == 'ACTIVE'){?>
                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#inactivePost<?php echo $id ?>"><i class="fa-solid fa-xmark"></i> INACTIVE</button>
                                <?php }
                                else{ ?>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#activatePost<?php echo $id ?>"><i class="fa-solid fa-check"></i> ACTIVATE</button>
                                <?php }?>
                            </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                                   
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    $sql1 = "SELECT * FROM tbl_post";
    $sqlres = mysqli_query($conn, $sql1);  
    while($row = mysqli_fetch_assoc($sqlres)){
        $id = $row['post_ID']; 
?>
<div class="modal fade" id="deletePost<?php echo $id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">      
                <center><i class="fa-solid fa-circle-exclamation" style ="color:red;font-size:100px;"></i><br><br>
                <p style="font-weight:bold; font-size:20px;">Are you sure you want to delete this user?</p></center>
                <div class="btnDelete" style = "display:flex;align-content:center;justify-content:center;gap:15px;">
                    <button type="submit" name="deletePost" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                <input type="hidden" name="postID" value="<?php echo $id ?>">
                </form>
            </div>  
        </div>
    </div>
</div>
<?php } ?>


<?php
    $sql2 = "SELECT * FROM tbl_post";
    $sqlres = mysqli_query($conn, $sql2);  
    while($row = mysqli_fetch_assoc($sqlres)){
        $id = $row['post_ID']; 
?>
<div class="modal fade" id="inactivePost<?php echo $id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">      
                <center><i class="fa-solid fa-circle-exclamation" style ="color:red;font-size:100px;"></i><br><br>
                <p style="font-weight:bold; font-size:20px;">Are you sure you want to deactivate this post?</p></center>
                <div class="btnDelete" style = "display:flex;align-content:center;justify-content:center;gap:15px;">
                    <button type="submit" name="deactivePost" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                <input type="hidden" name="postID" value="<?php echo $id ?>">
                </form>
            </div>  
        </div>
    </div>
</div>
<?php } ?>

<?php
    $sql2 = "SELECT * FROM tbl_post";
    $sqlres = mysqli_query($conn, $sql2);  
    while($row = mysqli_fetch_assoc($sqlres)){
        $id = $row['post_ID']; 
?>
<div class="modal fade" id="activatePost<?php echo $id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <form method="POST" action="index.php" enctype="multipart/form-data">      
                <center><i class="fa-solid fa-circle-exclamation" style ="color:red;font-size:100px;"></i><br><br>
                <p style="font-weight:bold; font-size:20px;">Are you sure you want to activate this post?</p></center>
                <div class="btnDelete" style = "display:flex;align-content:center;justify-content:center;gap:15px;">
                    <button type="submit" name="activatePost" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                <input type="hidden" name="postID" value="<?php echo $id ?>">
                </form>
            </div>  
        </div>
    </div>
</div>
<?php } ?>


<?php include '../includes/script.php'?>
</body>
</html>
<?php }
else {
   header("location: ../login.php");
}
?>