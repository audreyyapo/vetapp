    
  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
 

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
    <script>
    $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- font -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/js/brands.min.js"></script>
    
    <!-- ChartJS -->
    <script src="../lte/plugins/chart.js/Chart.min.js"></script>
    <!-- Sparkline -->
    <script src="../lte/plugins/sparklines/sparkline.js"></script>
    <!-- JQVMap -->
    <script src="../lte/plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="../lte/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="../lte/plugins/jquery-knob/jquery.knob.min.js"></script>
    <!-- daterangepicker -->
    <script src="../lte/plugins/moment/moment.min.js"></script>
    <script src="../lte/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Summernote -->
    <script src="../lte/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="../lte/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../lte/dist/js/adminlte.js"></script>
    <!--  data tables -->
    <script src="../lte/plugins/datatables/jquery.dataTables.js"></script>